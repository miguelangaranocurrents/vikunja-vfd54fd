# @currents/playwright

[Currents](https://currents.dev/playwright) is the most popular and advanced cloud-based platform for Playwright - debugging, error analysis, real-time analytics, orchestration, and more

<p align="center">
  <img width="830" src="https://static.currents.dev/npm_package_banner.png" />
</p>

[![npm version](https://img.shields.io/npm/v/@currents/playwright.svg)](https://www.npmjs.com/package/@currents/playwright)
[![npm dm](https://img.shields.io/npm/dm/@currents/playwright.svg)](https://www.npmjs.com/package/@currents/playwright)
[![npm dt](https://img.shields.io/npm/dt/@currents/playwright.svg)](https://www.npmjs.com/package/@currents/playwright)

<p align="center">
<a href="https://docs.currents.dev">Documentation</a> | <a href="https://currents.dev?utm_source=currents-playwright-readme">Currents</a>

</p>

## Key Features

**Real-time Test Analytics & Debugging**

- Real-time streaming of test results for reliable, high-performance reporting
- Trace files, videos, screenshots, and console output saved to cloud
- Comprehensive test history, trends analysis, and flakiness tracking
- Error insights and common failure pattern detection

**Integration & Automation**

- GitHub integration with inline PR comments and detailed error reports
- Slack notifications and alert for build status and failure alerts
- Issue tracker integrations to collaborate and extend your workflows
- REST API and HTTP Webhooks for custom integrations
- IDE Extension to troubleshoot failures with AI-powered insights without leaving your code

**Performance & Scale**

- Up to 40% faster CI Playwright tests with Orchestration - superior to native Playwright sharding
- Git information collection and association with CI builds
- History and trends browser on test and spec levels
- Selective test execution using powerful Actions engine that skips and quarantines tests on the fly

**Built for AI & Modern Development**

- IDE extension for instant feedback
- Fix With AI for automated error troubleshooting
- MCP (Model Context Protocol) for effective automation
- Start debugging immediately - the results are available in real time

**Enterprise Ready**

- SOC2 compliant and trusted by leading companies
- Monitoring test suite performance with automated reporting
- Flexible, usage-based plans for every type of organization

---

## Requirements

- NodeJS 20+
- Playwright 1.40.1+

## Install

```sh
npm install @currents/playwright
```

## Enable traces, screenshots and videos

```js
use: {
  // ...
  trace: "retain-on-failure-and-retries",
  video: "retain-on-failure",
  screenshot: "on",
}
```

## Getting Started

<details>
<summary><strong>🤖 Want to hand this off to AI?</strong> Copy the prompt below into Cursor, Claude, ChatGPT, or your editor assistant and let it wire up the basics for you.</summary>

```
Your task is to update Playwright setup to report test results to Currents.dev

1. Install "@currents/playwright" package:

- as a development dependency
- using the project's package manager (npm, pnpm, yarn, etc...)

2. Update the Playwright configuration file (playwright.config.ts|js|mjs):

  - enable traces, videos and screenshots by updating the "use" property, e.g.:

  use: {
    trace: "retain-on-failure-and-retries",
    video: "retain-on-failure",
    screenshot: "on",
  }

  - add Currents test reporter, keep any existing reporters. Example:

  // playwright.config.ts
  import { defineConfig, devices, PlaywrightTestConfig } from "@playwright/test";
  import { currentsReporter } from "@currents/playwright";

  export default defineConfig({
    // ...
    reporter: [currentsReporter()], // add Currents reporter
  });

3. Create a new "currents.config.ts" file next to the existing playwright.config.ts|js|mjs file.

- use the same extension
- add the content below

import { CurrentsConfig } from "@currents/playwright";

const config: CurrentsConfig = {
  recordKey: process.env.CURRENTS_RECORD_KEY!,
  projectId: process.env.CURRENTS_PROJECT_ID!
};

export default config;
```

</details>

Start reporting test results to Currents in just minutes. Head to the [Getting Started Guide](https://docs.currents.dev/getting-started/your-first-playwright-run) for step-by-step setup instructions.

The guide covers:

- Installing `@currents/playwright`
- Adding the Currents reporter to your Playwright config
- Running your first test

## Orchestration - Speed Up Your Tests

Orchestration helps distribute tests across CI machines for parallel execution, achieving **up to 40% faster test completion** compared to native Playwright sharding.

Instead of fixed sharding, Currents uses historical timing data to intelligently distribute tests, reducing CI time and costs.

Learn more in the [Orchestration Setup Guide](https://docs.currents.dev/guides/ci-optimization/playwright-orchestration).

## CI Integrations

Check out example repositories and guides for running Playwright tests on popular CI providers and recording results to Currents:

- [GitHub Actions](https://docs.currents.dev/getting-started/ci-setup/github-actions)
- [GitLab CI](https://docs.currents.dev/getting-started/ci-setup/gitlab)
- [Jenkins](https://docs.currents.dev/getting-started/ci-setup/jenkins)
- [CircleCI](https://docs.currents.dev/getting-started/ci-setup/playwright-circleci)
- [AWS CodeBuild](https://docs.currents.dev/getting-started/ci-setup/playwright-aws-code-build)
- [Azure DevOps](https://docs.currents.dev/getting-started/ci-setup/playwright-azure-devops)

For all CI/CD examples, see [currents-examples](https://github.com/currents-dev/currents-examples) repository.

## Documentation

Explore comprehensive guides to get started and master Currents:

- [Playwright Parallelization - Sharding and Orchestration](https://docs.currents.dev/guides/pw-parallelization)
- [Playwright Tags](https://docs.currents.dev/guides/playwright-tags)
- [Playwright Component Testing](https://docs.currents.dev/guides/playwright-component-testing)
- [Test Status & Results](https://docs.currents.dev/tests/test-status)
- [Record Key Setup](https://docs.currents.dev/guides/record-key)
- [CI Build ID Configuration](https://docs.currents.dev/guides/ci-build-id)

Visit [docs.currents.dev](https://docs.currents.dev) for the complete documentation.
