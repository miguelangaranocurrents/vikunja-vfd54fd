# Changelog

# [2.7.0](https://github.com/currents-dev/currents-playwright/compare/v2.6.0...v2.7.0) (2026-11-02)

### Bug Fixes

- bump follow-redirects to 1.16.2 in the nextjs and imported-tests examples [CSR-0] ([#1062](https://github.com/currents-dev/currents-playwright/issues/1062)) ([711eb36](https://github.com/currents-dev/currents-playwright/commit/711eb367a3ab508c3f5fb1d1aea8caf44bb08c4b)), closes [#1050](https://github.com/currents-dev/currents-playwright/issues/1050)
- bump undici from 6.29.1 to 7.30.1 [ENG-0] ([#1052](https://github.com/currents-dev/currents-playwright/issues/1052)) ([6f0cb7b](https://github.com/currents-dev/currents-playwright/commit/6f0cb7bd7e12a0ef7130a8e8cd3bb7b3f82a68bf))
- bump ws and @types/ws ([#1055](https://github.com/currents-dev/currents-playwright/issues/1055)) ([d9fd184](https://github.com/currents-dev/currents-playwright/commit/d9fd184037ee39ab189a648db8187b6b73baeb5c))
- don't count tests a halted pwc-p task never ran as ran ([8e16376](https://github.com/currents-dev/currents-playwright/commit/8e163768bfec353d88faab11978100a5d57130b1))
- exit 1 when pwc can't spawn playwright or a signal kills it [ENG-1919] ([f79d6c5](https://github.com/currents-dev/currents-playwright/commit/f79d6c5c814656c9f8b0335e7a48dc80e098ce06))
- pin @currents/rules to 0.1.0 [ENG-1981] ([#1051](https://github.com/currents-dev/currents-playwright/issues/1051)) ([3cf060c](https://github.com/currents-dev/currents-playwright/commit/3cf060ce81a33b7fe24910bcf26af59302814fed))
- print pwc's launch failure to stderr [ENG-1919] ([547f6a8](https://github.com/currents-dev/currents-playwright/commit/547f6a8f21c0413054c5ac5042b1eb36718288ea))
- read a task's attachment files before reporting it finished [ENG-1923] ([#1040](https://github.com/currents-dev/currents-playwright/issues/1040)) ([86a8497](https://github.com/currents-dev/currents-playwright/commit/86a8497b026e2248f06cc1cd59b8dafd304cb62d))
- read CURRENTS_CONTEXT_LINKS=false as off ([8960a33](https://github.com/currents-dev/currents-playwright/commit/8960a33df27b18d0e4b2318221a738434e535e9a))

### Features

- add a setting for the summary for agents and the REST API address ([10a1460](https://github.com/currents-dev/currents-playwright/commit/10a1460547bde846fa9c3ed2e37f43daaec0b158))
- capture the test list in Reporter.preprocess by default on Playwright 1.62+, CURRENTS_SUITE_HOOK=false turns it off [ENG-1965] ([#1047](https://github.com/currents-dev/currents-playwright/issues/1047)) ([1434256](https://github.com/currents-dev/currents-playwright/commit/1434256e73acc773a9121c117575b0a59906dc6c))
- print a summary for agents with a context link for each failed and flaky test ([0d61fba](https://github.com/currents-dev/currents-playwright/commit/0d61fba129abab17c130164a5ace41c06f3188e7))
- print one summary for agents per pwc-p machine ([5f4dda3](https://github.com/currents-dev/currents-playwright/commit/5f4dda36b237d7ef495054dd39cca3c51caa794f))
- request context links for a run's failed and flaky tests ([ff47080](https://github.com/currents-dev/currents-playwright/commit/ff47080519df58c0219ca89f5ab9197d79d67a2b))

# [2.6.0](https://github.com/currents-dev/currents-playwright/compare/v2.5.2...v2.6.0) (2026-10-26)

### Bug Fixes

- bump eslint-config-turbo from 2.10.7 to 2.11.8 ([#999](https://github.com/currents-dev/currents-playwright/issues/999)) ([b7c320a](https://github.com/currents-dev/currents-playwright/commit/b7c320aa719fceac2865f559ebe20cc9ceea08c3))
- bump ts-pattern from 5.9.0 to 5.9.2 ([#1000](https://github.com/currents-dev/currents-playwright/issues/1000)) ([4ec43ea](https://github.com/currents-dev/currents-playwright/commit/4ec43ea2bdced62cdfaf2f2841492e25210b38be))
- bump undici from 6.28.1 to 6.29.1 ([#1025](https://github.com/currents-dev/currents-playwright/issues/1025)) ([a7cc95f](https://github.com/currents-dev/currents-playwright/commit/a7cc95f0e07bb736d155523de202fce8c25b1efc))
- compare every built file with the installed reporter in measure-real ([3d73c1c](https://github.com/currents-dev/currents-playwright/commit/3d73c1c8515f26f8777996103d88f07ce0bdf16b))
- **examples:** take follow-redirects 1.16.1 for the credential-leak advisories ([b22a242](https://github.com/currents-dev/currents-playwright/commit/b22a242ea87cdd05af8eac4020ee6a6ed138c126))
- gzip every test-record request body ([f1b4c36](https://github.com/currents-dev/currents-playwright/commit/f1b4c3668b37e45f1912d5ed5f6894a2775f5fbd))
- harden the reporter output preview ([8a7cfaa](https://github.com/currents-dev/currents-playwright/commit/8a7cfaa7328f493dadee5a1d76c4b6a765018109))
- label an earlier attempt's error in compact output ([3bc2e8f](https://github.com/currents-dev/currents-playwright/commit/3bc2e8fe67547942b4621f3a301e6d5269294d20))
- make the nextjs example type check and build ([#995](https://github.com/currents-dev/currents-playwright/issues/995)) ([260078d](https://github.com/currents-dev/currents-playwright/commit/260078df854610ff12eb3177f85993055f660bb6))
- measure only the checked-out reporter build in measure-real ([8401591](https://github.com/currents-dev/currents-playwright/commit/8401591c0af50e5c0569951a824adf7871f48806))
- print a test's line only from its last attempt ([f477462](https://github.com/currents-dev/currents-playwright/commit/f477462402398a330f571c926faac7a623664b0e))
- remove the worker fixtures tmp dir when the run ends ([#989](https://github.com/currents-dev/currents-playwright/issues/989)) ([493bd32](https://github.com/currents-dev/currents-playwright/commit/493bd32b86d40dbce7272d9d0d167d01971f4b34))
- run the pwc scanner again when a directory vanishes during test file collection [ENG-1754] ([#996](https://github.com/currents-dev/currents-playwright/issues/996)) ([2d40692](https://github.com/currents-dev/currents-playwright/commit/2d406928b2807d2bcf9bca9d1811fef221957192))
- show interrupted tests as interrupted ([74dd52c](https://github.com/currents-dev/currents-playwright/commit/74dd52c38debc486a339cfed2db151f7c98aab63))
- show the last attempt with failure details in compact output ([7e70326](https://github.com/currents-dev/currents-playwright/commit/7e703263058fb41775c9380a2d9f21d6da1cb6d0))

### Features

- add the compact console output preset ([007bd42](https://github.com/currents-dev/currents-playwright/commit/007bd42d0f1a5c6f33d7e3458fe59466c9075dd5))
- cache project rules per parent process to cut GET /rules traffic ([#988](https://github.com/currents-dev/currents-playwright/issues/988)) ([df3ff45](https://github.com/currents-dev/currents-playwright/commit/df3ff45d60e3d3f156b76dc0fce30ed6e922da37))
- send one machine id per reporter process [ENG-1818] ([#1024](https://github.com/currents-dev/currents-playwright/issues/1024)) ([c4f8f81](https://github.com/currents-dev/currents-playwright/commit/c4f8f8198a14f80bfd02829eb168805c51d1d5c9))
- send the shard this process ran with the run [ENG-1818] ([#1030](https://github.com/currents-dev/currents-playwright/issues/1030)) ([4643559](https://github.com/currents-dev/currents-playwright/commit/4643559ab6a57542a228387aed5c87f58a9343ad))
- skip redundant POST /runs/v1 for orchestrated Playwright spawns [CSR-4229] ([#985](https://github.com/currents-dev/currents-playwright/issues/985)) ([39ed280](https://github.com/currents-dev/currents-playwright/commit/39ed280901ce3b40651020dafbb4555a117b64b8))

## [2.5.2](https://github.com/currents-dev/currents-playwright/compare/v2.5.1...v2.5.2) (2026-10-05)

### Bug Fixes

- bump ip-address from 10.5.0 to 10.7.2 ([a516f69](https://github.com/currents-dev/currents-playwright/commit/a516f69f3ad7bf6e7478711fcf2cc3aecf2f683a))
- bump undici from 6.28.0 to 6.28.1 ([4251a3c](https://github.com/currents-dev/currents-playwright/commit/4251a3cbf092072c63b77120b14504582b5165e2))
- take the commit and its CI fallback from commit-info 2.0 [ENG-1687] ([#979](https://github.com/currents-dev/currents-playwright/issues/979)) ([6651095](https://github.com/currents-dev/currents-playwright/commit/6651095c10881f8200ed5bcec655f9ff2701f4e4))

## [2.5.2-beta.0](https://github.com/currents-dev/currents-playwright/compare/v2.5.1...v2.5.2-beta.0) (2026-10-05)

### Bug Fixes

- bump ip-address from 10.5.0 to 10.7.2 ([a516f69](https://github.com/currents-dev/currents-playwright/commit/a516f69f3ad7bf6e7478711fcf2cc3aecf2f683a))
- bump undici from 6.28.0 to 6.28.1 ([4251a3c](https://github.com/currents-dev/currents-playwright/commit/4251a3cbf092072c63b77120b14504582b5165e2))
- take the commit and its CI fallback from commit-info 2.0 [ENG-1687] ([#979](https://github.com/currents-dev/currents-playwright/issues/979)) ([6651095](https://github.com/currents-dev/currents-playwright/commit/6651095c10881f8200ed5bcec655f9ff2701f4e4))

## [2.5.1](https://github.com/currents-dev/currents-playwright/compare/v2.5.0...v2.5.1) (2026-09-24)

### Bug Fixes

- bump brace-expansion from 5.0.8 to 5.0.9 ([#945](https://github.com/currents-dev/currents-playwright/issues/945)) ([e17381b](https://github.com/currents-dev/currents-playwright/commit/e17381b943be0bf8099040e9e5390d41e0ed93f3))
- bump eslint-config-turbo from 2.10.5 to 2.10.7 ([#935](https://github.com/currents-dev/currents-playwright/issues/935)) ([4197dda](https://github.com/currents-dev/currents-playwright/commit/4197ddabe6485c14a10e64ed33d20ea32d144e37))
- bump ip-address from 10.2.0 to 10.4.0 ([#943](https://github.com/currents-dev/currents-playwright/issues/943)) ([4678740](https://github.com/currents-dev/currents-playwright/commit/467874003bbad7a8383822d963239a98839a70d9))
- bump nanoid from 3.3.12 to 3.3.18 in /examples ([#948](https://github.com/currents-dev/currents-playwright/issues/948)) ([ea5f3dd](https://github.com/currents-dev/currents-playwright/commit/ea5f3dde1050e31259e045f632f63209e8358f93))
- bump postcss from 8.5.18 to 8.5.25 ([#946](https://github.com/currents-dev/currents-playwright/issues/946)) ([4995e1c](https://github.com/currents-dev/currents-playwright/commit/4995e1c731cb66a2ba9942b1a6fa8807cb524c14))
- bump undici from 6.27.0 to 6.28.0 ([#944](https://github.com/currents-dev/currents-playwright/issues/944)) ([51e8c37](https://github.com/currents-dev/currents-playwright/commit/51e8c3738594ba5844da26443160da511ae88dc8))
- bump ws from 8.21.0 to 8.21.3 ([#951](https://github.com/currents-dev/currents-playwright/issues/951)) ([1524587](https://github.com/currents-dev/currents-playwright/commit/1524587dce8a43ce259d16823ac1f3067a26d965))
- **e2e:** stabilize or8n pending-child force-exit assertions ([#933](https://github.com/currents-dev/currents-playwright/issues/933)) ([54a7512](https://github.com/currents-dev/currents-playwright/commit/54a7512daa7ef66b4b9b4b91bd38b86f74214692))
- record the pull request's commit when CI checks out a merge commit ([7d1485b](https://github.com/currents-dev/currents-playwright/commit/7d1485b608a613b4bfc2fd1b8255b4cd45785387))

## [2.5.1-beta.0](https://github.com/currents-dev/currents-playwright/compare/v2.5.0...v2.5.1-beta.0) (2026-09-24)

### Bug Fixes

- bump brace-expansion from 5.0.8 to 5.0.9 ([#945](https://github.com/currents-dev/currents-playwright/issues/945)) ([e17381b](https://github.com/currents-dev/currents-playwright/commit/e17381b943be0bf8099040e9e5390d41e0ed93f3))
- bump eslint-config-turbo from 2.10.5 to 2.10.7 ([#935](https://github.com/currents-dev/currents-playwright/issues/935)) ([4197dda](https://github.com/currents-dev/currents-playwright/commit/4197ddabe6485c14a10e64ed33d20ea32d144e37))
- bump ip-address from 10.2.0 to 10.4.0 ([#943](https://github.com/currents-dev/currents-playwright/issues/943)) ([4678740](https://github.com/currents-dev/currents-playwright/commit/467874003bbad7a8383822d963239a98839a70d9))
- bump nanoid from 3.3.12 to 3.3.18 in /examples ([#948](https://github.com/currents-dev/currents-playwright/issues/948)) ([ea5f3dd](https://github.com/currents-dev/currents-playwright/commit/ea5f3dde1050e31259e045f632f63209e8358f93))
- bump postcss from 8.5.18 to 8.5.25 ([#946](https://github.com/currents-dev/currents-playwright/issues/946)) ([4995e1c](https://github.com/currents-dev/currents-playwright/commit/4995e1c731cb66a2ba9942b1a6fa8807cb524c14))
- bump undici from 6.27.0 to 6.28.0 ([#944](https://github.com/currents-dev/currents-playwright/issues/944)) ([51e8c37](https://github.com/currents-dev/currents-playwright/commit/51e8c3738594ba5844da26443160da511ae88dc8))
- bump ws from 8.21.0 to 8.21.3 ([#951](https://github.com/currents-dev/currents-playwright/issues/951)) ([1524587](https://github.com/currents-dev/currents-playwright/commit/1524587dce8a43ce259d16823ac1f3067a26d965))
- **e2e:** stabilize or8n pending-child force-exit assertions ([#933](https://github.com/currents-dev/currents-playwright/issues/933)) ([54a7512](https://github.com/currents-dev/currents-playwright/commit/54a7512daa7ef66b4b9b4b91bd38b86f74214692))
- record the pull request's commit when CI checks out a merge commit ([7d1485b](https://github.com/currents-dev/currents-playwright/commit/7d1485b608a613b4bfc2fd1b8255b4cd45785387))

# [2.5.0](https://github.com/currents-dev/currents-playwright/compare/v2.4.0...v2.5.0) (2026-07-16)

### Features

- add configurable orchestration session create timeout [ENG-891] ([#920](https://github.com/currents-dev/currents-playwright/issues/920)) ([f03f9be](https://github.com/currents-dev/currents-playwright/commit/f03f9be5b0f6063672edeb235e2a55d013a1f33e))

# [2.4.0](https://github.com/currents-dev/currents-playwright/compare/v2.3.2...v2.4.0) (2026-07-10)

### Bug Fixes

- recover stuck orchestrated Playwright children at shutdown [ENG-780] ([#904](https://github.com/currents-dev/currents-playwright/issues/904)) ([be31e24](https://github.com/currents-dev/currents-playwright/commit/be31e2452a4ae807a745f643d39bb5417c4c78e5))

## [2.3.3](https://github.com/currents-dev/currents-playwright/compare/v2.3.2...v2.3.3) (2026-06-24)

### Bug Fixes

- prevent silent discovery-list truncation in pwc-p discover [ENG-777] ([#902](https://github.com/currents-dev/currents-playwright/issues/902)) ([78fa6f3](https://github.com/currents-dev/currents-playwright/commit/78fa6f33c739c2b7342a519c21453b484353474d))

## [2.3.2](https://github.com/currents-dev/currents-playwright/compare/v2.3.1...v2.3.2) (2026-06-22)

### Bug Fixes

- buffer reporter output emitted before onBegin [ENG-746] ([#897](https://github.com/currents-dev/currents-playwright/issues/897)) ([9d8b43a](https://github.com/currents-dev/currents-playwright/commit/9d8b43ad76ed6d2fd97930e068a3791c607951db))
- bump form-data from 4.0.5 to 4.0.6 in /examples/imported-tests ([#889](https://github.com/currents-dev/currents-playwright/issues/889)) ([d99883f](https://github.com/currents-dev/currents-playwright/commit/d99883f0dc32792b765b3aeba4f3be27e3a4aa75))
- bump undici from 6.25.0 to 6.27.0 ([#890](https://github.com/currents-dev/currents-playwright/issues/890)) ([ec113f9](https://github.com/currents-dev/currents-playwright/commit/ec113f9061cd661f4676522cb1400491afeaa95b))

## [2.3.1](https://github.com/currents-dev/currents-playwright/compare/v2.3.0...v2.3.1) (2026-06-16)

### Bug Fixes

- @currents/playwright compatibility with Playwright 1.61.0 [ENG-680] ([#881](https://github.com/currents-dev/currents-playwright/issues/881)) ([87d233b](https://github.com/currents-dev/currents-playwright/commit/87d233b839bd357c425be559cdfbd43350dbc2b7))
- bump @babel/code-frame from 7.29.0 to 7.29.7 ([#875](https://github.com/currents-dev/currents-playwright/issues/875)) ([7576777](https://github.com/currents-dev/currents-playwright/commit/75767776743a5be817cfaf80fe9fac1f11f8011c))
- ensure pwc-p run rejects the -G flag ([#882](https://github.com/currents-dev/currents-playwright/issues/882)) ([172e974](https://github.com/currents-dev/currents-playwright/commit/172e9744557e26431d51df7507f78486c8bd0f59))

# [2.3.0](https://github.com/currents-dev/currents-playwright/compare/v2.2.0...v2.3.0) (2026-06-05)

### Features

- compress coverage upload [ENG-575] ([#871](https://github.com/currents-dev/currents-playwright/issues/871)) ([b31bc36](https://github.com/currents-dev/currents-playwright/commit/b31bc3678ccde30278c2d3e69f469d2ee91afb1e))
- gzip-compress instance stdout artifact uploads [ENG-574] ([#869](https://github.com/currents-dev/currents-playwright/issues/869)) ([54681cd](https://github.com/currents-dev/currents-playwright/commit/54681cd645e8660ebe956b51cb2b76b3100abe0b))

# [2.2.0](https://github.com/currents-dev/currents-playwright/compare/v2.1.4...v2.2.0) (2026-06-02)

### Bug Fixes

- bump jiti from 2.6.1 to 2.7.0 ([#863](https://github.com/currents-dev/currents-playwright/issues/863)) ([7c074b2](https://github.com/currents-dev/currents-playwright/commit/7c074b241f6982a57f146ab85ae1d730bd5e1987))
- bump tmp from 0.2.6 to 0.2.7 ([#865](https://github.com/currents-dev/currents-playwright/issues/865)) ([293915d](https://github.com/currents-dev/currents-playwright/commit/293915d1a47a526ffe06ac95dc341eb59afe8be7))

### Features

- use unidici and drop axios [ENG-568] ([#836](https://github.com/currents-dev/currents-playwright/issues/836)) ([a3d7f72](https://github.com/currents-dev/currents-playwright/commit/a3d7f72df8ebd7e851687cce6f72b668b0867a26)), closes [#813](https://github.com/currents-dev/currents-playwright/issues/813)

## [2.1.4](https://github.com/currents-dev/currents-playwright/compare/v2.1.3...v2.1.4) (2026-05-29)

### Bug Fixes

- restore git-preferred commit merge and clean CI branch names [ENG-563] ([#859](https://github.com/currents-dev/currents-playwright/issues/859)) ([a661071](https://github.com/currents-dev/currents-playwright/commit/a6610719e7c0e807a4677add101284b5ec6e029b))

## [2.1.3](https://github.com/currents-dev/currents-playwright/compare/v2.1.2...v2.1.3) (2026-05-29)

### Bug Fixes

- adopt CURRENTS_CI_URL as ciUrl config option [ENG-561] ([ef9326b](https://github.com/currents-dev/currents-playwright/commit/ef9326b3dd3728834d3bb86422ee915afd45aa6a))
- bump tmp from 0.2.5 to 0.2.6 ([#853](https://github.com/currents-dev/currents-playwright/issues/853)) ([73a765d](https://github.com/currents-dev/currents-playwright/commit/73a765d42c7599c251289457753d5689075405b6))
- bump tmp from 0.2.5 to 0.2.7 in /examples ([#852](https://github.com/currents-dev/currents-playwright/issues/852)) ([8beb700](https://github.com/currents-dev/currents-playwright/commit/8beb700ca00b087bdee1882842965363373765d1))
- bump tmp from 0.2.5 to 0.2.7 in /examples/imported-tests ([#855](https://github.com/currents-dev/currents-playwright/issues/855)) ([ba99ef2](https://github.com/currents-dev/currents-playwright/commit/ba99ef2cb6b415177e76f708fd128f16dc7d1910))
- update dependencies in package-lock.json and package.json ([#858](https://github.com/currents-dev/currents-playwright/issues/858)) ([5295543](https://github.com/currents-dev/currents-playwright/commit/52955430f2c09b0f59d82ac81907f1f300370bd7))

## [2.1.2](https://github.com/currents-dev/currents-playwright/compare/v2.1.1...v2.1.2) (2026-05-26)

## [2.1.1](https://github.com/currents-dev/currents-playwright/compare/v2.1.0...v2.1.1) (2026-05-22)

### Bug Fixes

- include the fully parallel flag into the accepted flags for pwc-p run. ([#840](https://github.com/currents-dev/currents-playwright/issues/840)) ([34615d4](https://github.com/currents-dev/currents-playwright/commit/34615d4da4151d33c27e2efda0dfb3d5a9ec42a8))

# [2.1.0](https://github.com/currents-dev/currents-playwright/compare/v2.0.0...v2.1.0) (2026-05-22)

### Features

- add --pwc-environment option and discovery environment field [CSR-3613] ([#833](https://github.com/currents-dev/currents-playwright/issues/833)) ([3164c33](https://github.com/currents-dev/currents-playwright/commit/3164c335e3bb82db1794a65a8223442b5dae4718))
- azure ci data [CSR-4184] ([#816](https://github.com/currents-dev/currents-playwright/issues/816)) ([d452c27](https://github.com/currents-dev/currents-playwright/commit/d452c276f53b21fc7b920ae199d10a27e96a4fc4))

# [2.0.0](https://github.com/currents-dev/currents-playwright/compare/v1.23.2...v2.0.0) (2026-05-19)

### Breaking changes

Breaking changes for orchestration (`pwc-p`) only.
See the upgrade guide at https://docs.currents.dev/resources/reporters/currents-playwright/migration-to-playwright-1.60

- Update uses of `pwc-p` with the run subcommand `pwc-p run`
- Any Playwright flags for filenames that were used for discovery/filtering need to be passed to `pwc-p discover` rather than `pwc-p run`

### Bug Fixes

- bump dotenv from 17.2.3 to 17.4.2 ([#820](https://github.com/currents-dev/currents-playwright/issues/820)) ([6e177b4](https://github.com/currents-dev/currents-playwright/commit/6e177b49295b636f7a94b3ce01b5b3107053e11c))
- bump ws from 8.19.0 to 8.20.1 ([#826](https://github.com/currents-dev/currents-playwright/issues/826)) ([256f08c](https://github.com/currents-dev/currents-playwright/commit/256f08cdfcb5c0809028f7a2efe4ec7f581cf7ed))
- bump ws from 8.20.0 to 8.20.1 in /examples ([#828](https://github.com/currents-dev/currents-playwright/issues/828)) ([e927257](https://github.com/currents-dev/currents-playwright/commit/e927257403e777da2f89dfa34d1b6584fc549633))
- remove projectTags from createRun payload ([#829](https://github.com/currents-dev/currents-playwright/issues/829)) ([63e1630](https://github.com/currents-dev/currents-playwright/commit/63e163071ee83d013682a3f57a8db21431041047))
- surface Playwright errors in discovery reporter ([#832](https://github.com/currents-dev/currents-playwright/issues/832)) ([01da80d](https://github.com/currents-dev/currents-playwright/commit/01da80d4a4b137d1960857dbf0552e4f413137e3))
- correct path references in sharded test setup for fixture configuration ([0a1cebb](https://github.com/currents-dev/currents-playwright/commit/0a1cebb413a86e6f3f7d49de38927f15096b22b6))
- update path for last-run JSON fixture in discovery last-failed assertions ([23edebd](https://github.com/currents-dev/currents-playwright/commit/23edebdaee489f12cdff883861edd5f50c787c74))
- bump axios from 1.15.0 to 1.16.0 ([#809](https://github.com/currents-dev/currents-playwright/issues/809)) ([0943075](https://github.com/currents-dev/currents-playwright/commit/09430754181ff6356a68b89680d6e2ad37d3d947))
- bump axios from 1.15.0 to 1.16.0 in /examples/imported-tests ([#810](https://github.com/currents-dev/currents-playwright/issues/810)) ([839edb1](https://github.com/currents-dev/currents-playwright/commit/839edb1c7fcc58de42d9fd6362f2b7b57028a9bc))
- bump follow-redirects from 1.15.11 to 1.16.0 ([#801](https://github.com/currents-dev/currents-playwright/issues/801)) ([4299407](https://github.com/currents-dev/currents-playwright/commit/429940704e90fd3313a9a8de1989c8894eccb9b9))
- bump postcss from 8.5.9 to 8.5.10 ([#800](https://github.com/currents-dev/currents-playwright/issues/800)) ([cfd9556](https://github.com/currents-dev/currents-playwright/commit/cfd9556b674f2d459cc55a5196294ae2506839f1))

### Features

- v2 [CSR-4280] ([#815](https://github.com/currents-dev/currents-playwright/issues/815)) ([5e1dff7](https://github.com/currents-dev/currents-playwright/commit/5e1dff7b91e82ba736cf10fc44144cfa5c9cde65))
- add pwc-p discover and pwc-p run subcommands [CSR-4282] ([#813](https://github.com/currents-dev/currents-playwright/issues/813)) ([efb1303](https://github.com/currents-dev/currents-playwright/commit/efb1303898f9e129f8ead3c3d02b05a154a45e84))
- enhance orchestration reporter with onExit handling for cleanup and error notification ([22d1842](https://github.com/currents-dev/currents-playwright/commit/22d18428ffe14112a1ac277430b03f5e8bb971c7))
- Restore compatiblilty with Playwright 1.60.0

## [1.23.2](https://github.com/currents-dev/currents-playwright/compare/v1.23.1...v1.23.2) (2026-04-17)

### Bug Fixes

- retain trace for quarantine in retain-on-failures trace mode ([1f271c1](https://github.com/currents-dev/currents-playwright/commit/1f271c188296fc5f6a8e3631c8c8ec035bd60ef3))

## [1.23.1](https://github.com/currents-dev/currents-playwright/compare/v1.23.0...v1.23.1) (2026-04-16)

### Bug Fixes

- project dependencies missing in discovery when filtered by last-failed [CSR-4073] ([#785](https://github.com/currents-dev/currents-playwright/issues/785)) ([480bb59](https://github.com/currents-dev/currents-playwright/commit/480bb590088479d56ab3489c438f006bfe768535)), closes [#788](https://github.com/currents-dev/currents-playwright/issues/788)
- run only id-only preOnlyTestFilters in discovery scanner [CSR-4094] ([#790](https://github.com/currents-dev/currents-playwright/issues/790)) ([288a240](https://github.com/currents-dev/currents-playwright/commit/288a240357745cb43748b7ac32a749eab4a11e0e))

# [1.23.0](https://github.com/currents-dev/currents-playwright/compare/v1.22.3...v1.23.0) (2026-04-09)

### Bug Fixes

- bump axios from 1.13.6 to 1.15.0 in /packages/reporter [CSR-0] ([#768](https://github.com/currents-dev/currents-playwright/issues/768)) ([ae42763](https://github.com/currents-dev/currents-playwright/commit/ae427638542cf8a1f47e4a700fd25c48f7fb97f7))
- bump lodash from 4.17.23 to 4.18.1 ([#767](https://github.com/currents-dev/currents-playwright/issues/767)) ([017e881](https://github.com/currents-dev/currents-playwright/commit/017e881d245c6fd80acfa9abe4164b48a063b358))
- enhance CI provider detection and PR env capture [CSR-4046] ([#765](https://github.com/currents-dev/currents-playwright/issues/765)) ([d2bd16e](https://github.com/currents-dev/currents-playwright/commit/d2bd16e272eaf37bfb181168eafc7f672df4d13b))

### Features

- add visual testing example ([#738](https://github.com/currents-dev/currents-playwright/issues/738)) ([5b04482](https://github.com/currents-dev/currents-playwright/commit/5b044829d6c7c1adad471f5a1795f904d0866450))

## [1.22.3](https://github.com/currents-dev/currents-playwright/compare/v1.22.2...v1.22.3) (2026-03-31)

### Bug Fixes

- update axios and axios-retry to specific versions in reporter package ([#759](https://github.com/currents-dev/currents-playwright/issues/759)) ([0571297](https://github.com/currents-dev/currents-playwright/commit/0571297dbd16c899d2fa0772051e76686cf6fa54))

## [1.22.2](https://github.com/currents-dev/currents-playwright/compare/v1.22.1...v1.22.2) (2026-03-25)

### Bug Fixes

- or8n strip --project from task creation [CSR-4003] ([#752](https://github.com/currents-dev/currents-playwright/issues/752)) ([a698fd0](https://github.com/currents-dev/currents-playwright/commit/a698fd0ecafcc81b382d0fac1e12970e1e212c85))

## [1.22.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.22.0...v1.22.1) (2026-03-20)

### Bug Fixes

- **reporter:** support commander v13 and excess argv ([82d6aa7](https://github.com/currents-dev/currents-playwright-changelog/commit/82d6aa715547f257c816a2abd4db507d11fdfafe))

# [1.22.0](https://github.com/currents-dev/currents-playwright/compare/v1.21.2...v1.22.0) (2026-03-03)

### Bug Fixes

- added interrupted test case if any element is interrupted [CSR-3876] ([#729](https://github.com/currents-dev/currents-playwright/issues/729)) ([bdce6ee](https://github.com/currents-dev/currents-playwright/commit/bdce6eef2b69692a185e2e7aed62a104fe141ccb))
- bump @babel/code-frame from 7.28.6 to 7.29.0 ([#730](https://github.com/currents-dev/currents-playwright/issues/730)) ([3854f1d](https://github.com/currents-dev/currents-playwright/commit/3854f1d14c81ca7e610a68fa200c319dbdfe6fbc))
- bump pino from 10.3.0 to 10.3.1 ([#720](https://github.com/currents-dev/currents-playwright/issues/720)) ([cad86d3](https://github.com/currents-dev/currents-playwright/commit/cad86d337a852d1cc039f3ce7f5ff01f68a2a4dd))

### Features

- add consoleOutput flag for reporter output control [CSR-3433] ([#727](https://github.com/currents-dev/currents-playwright/issues/727)) ([fcbf845](https://github.com/currents-dev/currents-playwright/commit/fcbf845b8c29a30b73189d697dac537d83114208))

## [1.21.2](https://github.com/currents-dev/currents-playwright/compare/v1.21.1...v1.21.2) (2026-02-17)

### Bug Fixes

- bump axios from 1.13.2 to 1.13.5 ([#718](https://github.com/currents-dev/currents-playwright/issues/718)) ([9b9b131](https://github.com/currents-dev/currents-playwright/commit/9b9b131eb0187abf14e04c377907fa911edd0f02))
- bump pino from 9.14.0 to 10.2.0 ([#696](https://github.com/currents-dev/currents-playwright/issues/696)) ([03f25ef](https://github.com/currents-dev/currents-playwright/commit/03f25ef3890aa4331cfa7a0c5fd1e7e79d896e12))
- Support for deprecated --browser flag ([eb650fb](https://github.com/currents-dev/currents-playwright/commit/eb650fbb40052a36938a1fe61a286b5fb380b139))

## [1.21.1](https://github.com/currents-dev/currents-playwright/compare/v1.21.0...v1.21.1) (2026-02-05)

### Bug Fixes

- bump lodash from 4.17.21 to 4.17.23 ([#707](https://github.com/currents-dev/currents-playwright/issues/707)) ([f512fa3](https://github.com/currents-dev/currents-playwright/commit/f512fa31a9e52d1dd144476d65bb04ec9c9089e8))
- Orchestration exit code when cancelled (fail-fast) should always be 1 ([#712](https://github.com/currents-dev/currents-playwright/issues/712)) ([685f3c2](https://github.com/currents-dev/currents-playwright/commit/685f3c24e921fa27a772d9cb00be3fe081d3cb19))

# [1.21.0](https://github.com/currents-dev/currents-playwright/compare/v1.20.1...v1.21.0) (2026-01-19)

### Features

A small semantic change in reporting logic for interrupted tests. For example, if tests are stopped by playwright in the middle of execution because of "maxFailures" or SIGINT, the tests will show up as "interrupted" instead of "failed".

We still do not consider them as passed and a spec file or run having an interrupted test will be considered failed.

We bump the minor version to prevent automatic updates.

- report interrupted tets as "interrupted" instead of "failed" ([#689](https://github.com/currents-dev/currents-playwright/issues/689)) [CSR-3573] ([5caabe5](https://github.com/currents-dev/currents-playwright/commit/5caabe534a29b6367f974f8d3a4b35094ccc2c9b))

## [1.20.2](https://github.com/currents-dev/currents-playwright/compare/v1.20.1...v1.20.2) (2026-01-13)

### Bug Fixes

- Add additional debug logs to identify orchestration discovery timeouts ([#687](https://github.com/currents-dev/currents-playwright/issues/687)) ([853d026](https://github.com/currents-dev/currents-playwright/commit/853d026c58fdb87d1820ba301c3776e9a6494625))

## [1.20.1](https://github.com/currents-dev/currents-playwright/compare/v1.20.0...v1.20.1) (2025-12-29)

### Bug Fixes

- bump eslint from 9.35.0 to 9.39.2 ([#667](https://github.com/currents-dev/currents-playwright/issues/667)) ([625010d](https://github.com/currents-dev/currents-playwright/commit/625010d4c12ba2e40cea93b5fe1ba43a240e63e0))
- bump next from 15.4.8 to 15.4.9 ([#665](https://github.com/currents-dev/currents-playwright/issues/665)) ([54be510](https://github.com/currents-dev/currents-playwright/commit/54be510ad801f16453066b9a2d0f96d7e9f8948c))
- bump next from 15.4.9 to 15.4.10 ([#672](https://github.com/currents-dev/currents-playwright/issues/672)) ([eedc32f](https://github.com/currents-dev/currents-playwright/commit/eedc32f5e8f64e8109ec9a47127e97ab61a9dd81))
- handle orchestration cancellation without hanging [CSR-3540] ([#673](https://github.com/currents-dev/currents-playwright/issues/673)) ([ecf81f4](https://github.com/currents-dev/currents-playwright/commit/ecf81f46ee5cb64f9c82c90bcb48b9abf50f6d5a))

# [1.20.0](https://github.com/currents-dev/currents-playwright/compare/v1.17.0...v1.20.0) (2025-12-08)

### Bug Fixes

- bump axios from 1.12.2 to 1.13.2 ([#656](https://github.com/currents-dev/currents-playwright/issues/656)) ([deaa5c2](https://github.com/currents-dev/currents-playwright/commit/deaa5c2479d02a59efe6301343e5036095d323d0))
- bump dotenv from 17.2.2 to 17.2.3 ([7edbe4f](https://github.com/currents-dev/currents-playwright/commit/7edbe4fa5909ca7b4bb1da250d89bb266a4e35bc))
- Switch from c12 to using jiti directly for config loading ([a830bc6](https://github.com/currents-dev/currents-playwright/commit/a830bc63e690074582cdb943fa138454a8b1f169))

## [1.19.2](https://github.com/currents-dev/currents-playwright/compare/v1.19.1...v1.19.2) (2025-12-03)

### Bug Fixes

fix: set dotenv import as quiet to remove log
fix: downgrade c12 to reduce config loading timing issues

## [1.19.1](https://github.com/currents-dev/currents-playwright/compare/v1.17.0...v1.19.1) (2025-11-26)

### Bug Fixes

- Ensure error.value is used as message to our backend when error.message is undefined ([#633](https://github.com/currents-dev/currents-playwright/issues/633)) ([23ed437](https://github.com/currents-dev/currents-playwright/commit/23ed437e98d3dc474c14bc6bf8096efb755562a4))
- include project deps in error copy for fake test result [CSR-3401] ([#641](https://github.com/currents-dev/currents-playwright/issues/641)) ([7129974](https://github.com/currents-dev/currents-playwright/commit/7129974cc7f43f2e9d3668729f3a5bf54b3fc860))

# [1.19.0](https://github.com/currents-dev/currents-playwright/compare/v1.18.0...v1.19.0) (2025-11-10)

### Bug Fixes

- vscode pw extension compatibility [CSR-3311] ([#634](https://github.com/currents-dev/currents-playwright/issues/634)) ([cadbe14](https://github.com/currents-dev/currents-playwright/commit/cadbe14f8a39afd18530934370d952e364998abc))

# [1.18.0](https://github.com/currents-dev/currents-playwright/compare/v1.17.1...v1.18.0) (2025-11-04)

### Features

- Regex Pattern Actions [CSR-2854] ([#627](https://github.com/currents-dev/currents-playwright/issues/627)) ([06d650c](https://github.com/currents-dev/currents-playwright-changelog/commit/06d650c3f4dff697af80bb3663b9a42913d094f8))

## [1.17.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.17.0...v1.17.1) (2025-10-07)

### Bug Fixes

- Fixes pwc discovery support for --test-list and --test-list-invert ([a869ef3](https://github.com/currents-dev/currents-playwright-changelog/commit/a869ef388dd98cd89fb58788e66afdb551fa5526))

# [1.17.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.15.3...v1.17.0) (2025-09-30)

### Bug Fixes

- bump axios from 1.11.0 to 1.12.2 ([#598](https://github.com/currents-dev/currents-playwright-changelog/issues/598)) ([1e21928](https://github.com/currents-dev/currents-playwright-changelog/commit/1e219286547d16ea51ddd0770463586dccce02ff))
- bump debug from 4.4.1 to 4.4.3 ([68dafc9](https://github.com/currents-dev/currents-playwright-changelog/commit/68dafc95c6b84d99d7d1e2b135429a2f6ebd2a6d))
- bump dotenv from 16.5.0 to 17.2.1 ([ffee0d3](https://github.com/currents-dev/currents-playwright-changelog/commit/ffee0d3475afe89f2611854ce21234e1a755bf96))
- bump dotenv from 16.6.1 to 17.2.1 in /packages/reporter ([b0e9e6a](https://github.com/currents-dev/currents-playwright-changelog/commit/b0e9e6a9b053f0ec10d6e804300e5e95ee0d4d53))
- bump dotenv from 17.2.1 to 17.2.2 ([1a23936](https://github.com/currents-dev/currents-playwright-changelog/commit/1a239364ec6e436c3084555ad9355bb4f93d9a27))
- bump eslint from 9.29.0 to 9.31.0 ([6b67884](https://github.com/currents-dev/currents-playwright-changelog/commit/6b67884f775e6d004d2504622ec0b04e2ce11301))
- bump eslint from 9.31.0 to 9.35.0 ([2ce965f](https://github.com/currents-dev/currents-playwright-changelog/commit/2ce965f9f39dc30bbbe8aea8a0ebb34917def1e9))
- bump eslint-config-next from 15.3.1 to 15.4.2 ([#565](https://github.com/currents-dev/currents-playwright-changelog/issues/565)) ([2e6a3ae](https://github.com/currents-dev/currents-playwright-changelog/commit/2e6a3aeba3a9b3afca728256c3778286f9cccdd0))
- bump eslint-config-next from 15.4.2 to 15.5.4 ([2c3f46e](https://github.com/currents-dev/currents-playwright-changelog/commit/2c3f46e4f3299acbf0dda015285aea2eb83237a7))
- bump eslint-config-prettier from 9.1.0 to 10.1.8 ([c29abc7](https://github.com/currents-dev/currents-playwright-changelog/commit/c29abc7001516de7f2070f621b29640989b5bf41))
- bump eslint-config-prettier in /packages/eslint-config-custom ([e840d23](https://github.com/currents-dev/currents-playwright-changelog/commit/e840d234045b1518917ca2eeb25338a725ca49fa))
- bump eslint-config-turbo from 2.5.4 to 2.5.6 ([ba09609](https://github.com/currents-dev/currents-playwright-changelog/commit/ba09609a8cdcb2511021e26208a7c55868fafc7c))
- bump execa from 9.5.3 to 9.6.0 ([04c613a](https://github.com/currents-dev/currents-playwright-changelog/commit/04c613a495e7c7d637c536137d6c8f96f0132017))
- bump pino from 9.6.0 to 9.9.0 ([79108f4](https://github.com/currents-dev/currents-playwright-changelog/commit/79108f46d96ff231d6ff2be07a19afc4548e09f7))
- bump tmp from 0.2.3 to 0.2.5 ([#579](https://github.com/currents-dev/currents-playwright-changelog/issues/579)) ([2410538](https://github.com/currents-dev/currents-playwright-changelog/commit/2410538096ac1feae2aafc1aa5d281522d672848))
- Restore support for last-failed for pw 1.55 ([#587](https://github.com/currents-dev/currents-playwright-changelog/issues/587)) ([157004d](https://github.com/currents-dev/currents-playwright-changelog/commit/157004d1f3e3a22e91eb00ba4c6b2a68ebe35efd))

### Features

- add support for run and group level tags in rules fixture ([#585](https://github.com/currents-dev/currents-playwright-changelog/issues/585)) ([8f3cf69](https://github.com/currents-dev/currents-playwright-changelog/commit/8f3cf6939ada5551c6d29feac9887c1148deac3d))
- rename disableTitleTags option to disableTestTags [CSR-3000] ([#590](https://github.com/currents-dev/currents-playwright-changelog/issues/590)) ([7cd9928](https://github.com/currents-dev/currents-playwright-changelog/commit/7cd9928b30feb17d98988b400c6a48a1d9131db9))

# [1.16.0](https://github.com/currents-dev/currents-playwright/compare/v1.15.3...v1.16.0) (2025-08-20)

### Bug Fixes

- bump tmp from 0.2.3 to 0.2.5 ([#579](https://github.com/currents-dev/currents-playwright/issues/579)) ([2410538](https://github.com/currents-dev/currents-playwright/commit/2410538096ac1feae2aafc1aa5d281522d672848))
- Restore support for last-failed for pw 1.55 ([#587](https://github.com/currents-dev/currents-playwright/issues/587)) ([157004d](https://github.com/currents-dev/currents-playwright/commit/157004d1f3e3a22e91eb00ba4c6b2a68ebe35efd))

### Features

- add support for run and group level tags in rules fixture ([#585](https://github.com/currents-dev/currents-playwright/issues/585)) ([8f3cf69](https://github.com/currents-dev/currents-playwright/commit/8f3cf6939ada5551c6d29feac9887c1148deac3d))

## [1.15.3](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.15.2...v1.15.3) (2025-07-19)

### Bug Fixes

- promisify and await ws.send function [CSR-2912] ([#563](https://github.com/currents-dev/currents-playwright-changelog/issues/563)) ([d599082](https://github.com/currents-dev/currents-playwright-changelog/commit/d5990825300e851048db7b56ca7206e21b83b2c7))

## [1.15.2](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.15.1...v1.15.2) (2025-07-15)

### Bug Fixes

- show correctly maxFailures warning [CSR-2866] ([#557](https://github.com/currents-dev/currents-playwright-changelog/issues/557)) ([098edf4](https://github.com/currents-dev/currents-playwright-changelog/commit/098edf4c10d02708b43f117ed30d822ce3f68ee4))

## [1.15.1](https://github.com/currents-dev/currents-playwright/compare/v1.15.0...v1.15.1) (2025-07-04)

### Bug Fixes

- ansi error message matching in actions ([#548](https://github.com/currents-dev/currents-playwright/issues/548)) ([738c91e](https://github.com/currents-dev/currents-playwright/commit/738c91edb20dd027bec22a52d8ae4e94bca08d17))

# [1.15.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.13.3...v1.15.0) (2025-07-02)

### Bug Fixes

- bump axios from 1.9.0 to 1.10.0 ([#544](https://github.com/currents-dev/currents-playwright-changelog/issues/544)) ([321a301](https://github.com/currents-dev/currents-playwright-changelog/commit/321a30151c8c13f5a20d956bd4f0fa9feb4297cf))
- bump ws from 8.18.2 to 8.18.3 ([#545](https://github.com/currents-dev/currents-playwright-changelog/issues/545)) ([530a7af](https://github.com/currents-dev/currents-playwright-changelog/commit/530a7afd864080541edd5311aa0facf42b3b76e3))

### Features

- Support upcoming Add Tag Currents Action [CSR-1988] ([#471](https://github.com/currents-dev/currents-playwright-changelog/issues/471)) ([5243c29](https://github.com/currents-dev/currents-playwright-changelog/commit/5243c293ded80d9087b264b50bd05082678333be))

## [1.14.2](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.14.2-beta.0...v1.14.2) (2025-06-24)

## [1.14.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.13.3...v1.14.1) (2025-06-16)

### Bug Fixes

- wait for reporters like blob reporter before starting new tasks [CSR-2742] ([#524](https://github.com/currents-dev/currents-playwright-changelog/issues/524)) ([cbc34e2](https://github.com/currents-dev/currents-playwright-changelog/commit/cbc34e2445482d7358ad32da5cd9669b11aae213))

## [1.14.1-alpha.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.14.1-alpha.0...v1.14.1-alpha.1) (2025-06-13)

### Bug Fixes

- run currents reporter last ([59ba9f4](https://github.com/currents-dev/currents-playwright-changelog/commit/59ba9f42d4b95b8e00da81b280a9199bdc47c334))

## [1.14.1-alpha.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.13.3...v1.14.1-alpha.0) (2025-06-12)

### Features

- Allow disabling orchestration event mode ([8f1fcdd](https://github.com/currents-dev/currents-playwright-changelog/commit/8f1fcdd49b4fed214c7ea7d860d037a246f1086a))

# [1.14.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.14.0-beta.0...v1.14.0) (2025-06-09)

### Features

- Add support for upcoming error message actions ([75a3a6b](https://github.com/currents-dev/currents-playwright/commit/75a3a6b4e527a96dfcd69b39b104a9db373be19a))
- support project level workers and batch size ([#495](https://github.com/currents-dev/currents-playwright/issues/495))

### Bug Fixes

- bump ts-pattern from 5.7.0 to 5.7.1 ([#520](https://github.com/currents-dev/currents-playwright/issues/520)) ([4e79425](https://github.com/currents-dev/currents-playwright/commit/4e79425ae27b22745ff2b428b1ad261f58427a42))
- bump ws from 8.18.1 to 8.18.2 ([#521](https://github.com/currents-dev/currents-playwright/issues/521)) ([43e18f0](https://github.com/currents-dev/currents-playwright/commit/43e18f0f07469f35660c23b2caddd79bbac118f0))
- await for uploads before starting the next or8n task for reruns [CSR-2683] ([#516](https://github.com/currents-dev/currents-playwright/issues/516)) ([2ffbd18](https://github.com/currents-dev/currents-playwright/commit/2ffbd180d4c32c9af3b9f967ada7815375f95891))
- escape special characters for spec files in orchestration [CSR-2675] ([#501](https://github.com/currents-dev/currents-playwright/issues/501)) ([09eef4c](https://github.com/currents-dev/currents-playwright/commit/09eef4c24c4422bb50706aed5224504f16daad24))

# [1.14.0-beta.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.13.3...v1.14.0-beta.0) (2025-06-05)

### Bug Fixes

- await for uploads before starting the next or8n task for reruns [CSR-2683] ([#516](https://github.com/currents-dev/currents-playwright/issues/516)) ([2ffbd18](https://github.com/currents-dev/currents-playwright/commit/2ffbd180d4c32c9af3b9f967ada7815375f95891))
- escape special characters for spec files in orchestration [CSR-2675] ([#501](https://github.com/currents-dev/currents-playwright/issues/501)) ([09eef4c](https://github.com/currents-dev/currents-playwright/commit/09eef4c24c4422bb50706aed5224504f16daad24))

### Features

- Add support for upcoming error message actions ([75a3a6b](https://github.com/currents-dev/currents-playwright/commit/75a3a6b4e527a96dfcd69b39b104a9db373be19a))
- support project level workers and batch size ([#495](https://github.com/currents-dev/currents-playwright/issues/495))

## [1.13.4](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.13.3...v1.13.4) (2025-05-30)

### Bug Fixes

- escape special characters for spec files in orchestration [CSR-2675] ([#501](https://github.com/currents-dev/currents-playwright/issues/501)) ([09eef4c](https://github.com/currents-dev/currents-playwright/commit/09eef4c24c4422bb50706aed5224504f16daad24))

## [1.13.3](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.13.2...v1.13.3) (2025-05-29)

### Bug Fixes

- coverage fixture issue with file truncations ([#500](https://github.com/currents-dev/currents-playwright/pull/500))

## [1.13.2](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.13.1...v1.13.2) (2025-05-21)

## [1.13.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.13.0...v1.13.1) (2025-05-16)

### Bug Fixes

- prevent overriding NODE_OPTIONS for pwc ([#491](https://github.com/currents-dev/currents-playwright-changelog/issues/491)) ([b344fdc](https://github.com/currents-dev/currents-playwright-changelog/commit/b344fdce935455d05531fde736c76807080c4698))

# [1.13.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.12.6...v1.13.0) (2025-05-13)

### Features

- enable support for batched orchestration ([#487](https://github.com/currents-dev/currents-playwright-changelog/issues/487)) ([b89cffa](https://github.com/currents-dev/currents-playwright-changelog/commit/b89cffa640150edeac3d3b6384104c9cdd981da7))

# [1.13.0-beta.2](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.12.5...v1.13.0-beta.2) (2025-05-12)

### Bug Fixes

- update prettier and eslint-config-turbo to latest versions; add undici-types dependency ([021839e](https://github.com/currents-dev/currents-playwright-changelog/commit/021839e7f517d31c5b788895a11f6140cf8d6fb4))

# [1.13.0-beta.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.12.5...v1.13.0-beta.2) (2025-04-29)

# [1.13.0-beta.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.12.5...v1.13.0-beta.2) (2025-04-28)

### Features

- allow receiving batched orchestration tasks ([832e30f](https://github.com/currents-dev/currents-playwright-changelog/commit/832e30f03da7d4f2c384a411c8f4abf0e84e1644))
- implement batched orchestration ([ea20c83](https://github.com/currents-dev/currents-playwright-changelog/commit/ea20c837fe43bbf82f629160d036c31ac7157f4c))
- use batched orchestration api to create session, fix log ([5150a9b](https://github.com/currents-dev/currents-playwright-changelog/commit/5150a9ba363a38fb1613300eea4a16e56ded8f09))

## [1.12.6](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.12.5...v1.12.6) (2025-05-12)

### Bug Fixes

- remove undefined or lacking type annotations ([#488](https://github.com/currents-dev/currents-playwright-changelog/issues/488)) ([28e81f8](https://github.com/currents-dev/currents-playwright-changelog/commit/28e81f84b62c629ef5c93527dce6de58739d608a))

## [1.12.5](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.12.4...v1.12.5) (2025-05-12)

### Bug Fixes

- add machine reset logic with global state in pwc-p-runner process ([#470](https://github.com/currents-dev/currents-playwright-changelog/issues/470)) ([51adb6f](https://github.com/currents-dev/currents-playwright-changelog/commit/51adb6fb506fbc875da98885d5d13c832c03728a))
- Bump @babel/code-frame from `7.26.2` to `7.27.1` ([#475](https://github.com/currents-dev/currents-playwright-changelog/issues/475)) ([3f9ec84](https://github.com/currents-dev/currents-playwright-changelog/commit/3f9ec845044550e195bf3b269afcb531b7512da9))
- bump execa from `9.5.2` to `9.5.3` ([8cfaca2](https://github.com/currents-dev/currents-playwright-changelog/commit/8cfaca2333e14010630b3910d3bb799decf4e7d9))

## [1.12.4](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.12.3...v1.12.4) (2025-05-09)

### Bug Fixes

- Support attempt level annotations [CSR-2502] ([#467](https://github.com/currents-dev/currents-playwright-changelog/issues/467)) ([04f265a](https://github.com/currents-dev/currents-playwright-changelog/commit/04f265a6b32674db0186fbc7fc51b6cbf14344fb))
- Update discovery for last failed to support sharding [CSR-2469] ([#455](https://github.com/currents-dev/currents-playwright-changelog/issues/455)) ([cbe8870](https://github.com/currents-dev/currents-playwright-changelog/commit/cbe8870c958fef83ddb982224c3f3c0f06f2f6d3)), closes [#466](https://github.com/currents-dev/currents-playwright-changelog/issues/466)
- Re-apply actions when afterAll hooks fail [CSR-2167] ([#445](https://github.com/currents-dev/currents-playwright/pull/445))

## [1.12.3](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.12.2...v1.12.3) (2025-04-29)

### Bug Fixes

- support --fail-on-flaky flag introduced in playwright v1.52.0 (#453)

## [1.12.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.12.0...v1.12.1) (2025-04-08)

### Bug Fixes

- discovery for last-failed reruns in playwright 1.50+ ([#432](https://github.com/currents-dev/currents-playwright-changelog/issues/432)) ([8f9ce48](https://github.com/currents-dev/currents-playwright-changelog/commit/8f9ce4822e32cfc585619dba9862dee4fed8736a))

# [1.12.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.11.7...v1.12.0) (2025-04-04)

### Features

- improved support of last failed with or8n [CSR-2354] ([#421](https://github.com/currents-dev/currents-playwright-changelog/issues/421)) ([b1790c5](https://github.com/currents-dev/currents-playwright-changelog/commit/b1790c57cf9e10508f60d8dc2454e0a42b0ca9a9))

### Bug Fixes

- handle Axios errors in runScript function ([#422](https://github.com/currents-dev/currents-playwright-changelog/issues/422)) ([5c89eb8](https://github.com/currents-dev/currents-playwright-changelog/commit/5c89eb8753e59a7327c9175794bb2eba682d0ddc))

## [1.11.7](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.11.6...v1.11.7) (2025-03-27)

### Bug Fixes

- disable fixtures when config is not available ([#411](https://github.com/currents-dev/currents-playwright-changelog/issues/411)) ([acec3a8](https://github.com/currents-dev/currents-playwright-changelog/commit/acec3a8d71590bbe19d8718331d73dab8eccc2ba))

## [1.11.6](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.11.5...v1.11.6) (2025-03-26)

## [1.11.5](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.11.3...v1.11.5) (2025-03-24)

### Bug Fixes

- Restore help from CLI programs, use shared debug option ([0772957](https://github.com/currents-dev/currents-playwright-changelog/commit/077295785648a71845492e589ca902176203f70a))

## [1.11.4](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.11.3...v1.11.4) (2025-03-18)

### Bug Fixes

- allow using currents config file with pwc-p ([c1c8be3](https://github.com/currents-dev/currents-playwright-changelog/commit/c1c8be399194b28c2c5c0686fdc1fcdd18feec06))

### Misc

- add remote debug artifact upload functionality and update reporter integration ([e72328a](https://github.com/currents-dev/currents-playwright-changelog/commit/e72328aeeb0707e63382b0c6b21b67329f2a05e4))
- use RemoteDebug class ([3ec3026](https://github.com/currents-dev/currents-playwright-changelog/commit/3ec30261436f345f0eafef2a8ba6a53044e1d1c5))
- init debug if config file defines it, arrange correct assertion for checking mandatory keys, restore load function ([f80f4a1](https://github.com/currents-dev/currents-playwright-changelog/commit/f80f4a125e0f981b8adb9424f8a0d6faf6bf0d14))
- move block to accept debug from reporter config, remove debug init from default reporter ([e728005](https://github.com/currents-dev/currents-playwright-changelog/commit/e7280053780699427a1e8b37002d680b50903cc0))
- prevent looping mandatoryConfigKeys if skipValidation is present ([c690a57](https://github.com/currents-dev/currents-playwright-changelog/commit/c690a57db2d4463fbf8d7b38c687d3308f8f0cb4))
- remove unused debug initialization and console log in DefaultReporter ([79541b9](https://github.com/currents-dev/currents-playwright-changelog/commit/79541b90754456aaaa48dc9c22182e7298c35379))

## [1.11.3](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.11.1...v1.11.3) (2025-03-11)

### Bug Fixes

- use debug level logs for coverage issues ([80da64f](https://github.com/currents-dev/currents-playwright-changelog/commit/80da64f6d897a1c9cbaa86edab2e0a64720ee14d))

## [1.11.2](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.11.1...v1.11.2) (2025-03-10)

## [1.11.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.11.0...v1.11.1) (2025-03-07)

### Bug Fixes

- actions, normalize tag matcher value ([f3caf46](https://github.com/currents-dev/currents-playwright/commit/f3caf46957e09a910781523f3bcfd5c7838dbbd1))

# [1.11.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.9.4...v1.11.0) (2025-03-04)

### Bug Fixes

- add try-catch block to sendCoverage ([c44f41e](https://github.com/currents-dev/currents-playwright-changelog/commit/c44f41ea80251d2e0e724c45d8ee41a66590298a))
- coverage example ([1fd5ffc](https://github.com/currents-dev/currents-playwright-changelog/commit/1fd5ffc1fc0869958e65793032ae7e2d697505e8))
- do not send coverage at test attempt level ([6315a9d](https://github.com/currents-dev/currents-playwright-changelog/commit/6315a9dc9170146bdfb07b336edb5451250a1df5))
- log an error when coverage file failed to load or parse ([f4f0ce3](https://github.com/currents-dev/currents-playwright-changelog/commit/f4f0ce3124bf7af18ecc58f26f95d9401c1c992d))
- send coverage at spec level ([c7ba2dd](https://github.com/currents-dev/currents-playwright-changelog/commit/c7ba2dd520333712d5365b30706dad65db5db5df))

# [1.10.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.9.4...v1.10.0) (2025-02-27)

### Features

- Add support for the includes action operator ([8f2faa1](https://github.com/currents-dev/currents-playwright-changelog/commit/8f2faa139aa3ab6bc99bf6979540b1c7884c73c1))

## [1.9.5-beta.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.9.4...v1.9.5-beta.1) (2025-02-23)

### Bug Fixes

- allow using currents config file with pwc-p ([c1c8be3](https://github.com/currents-dev/currents-playwright-changelog/commit/c1c8be399194b28c2c5c0686fdc1fcdd18feec06))
- init debug if config file defines it, arrange correct assertion for checking mandatory keys, restore load function ([f80f4a1](https://github.com/currents-dev/currents-playwright-changelog/commit/f80f4a125e0f981b8adb9424f8a0d6faf6bf0d14))
- move block to accept debug from reporter config, remove debug init from default reporter ([e728005](https://github.com/currents-dev/currents-playwright-changelog/commit/e7280053780699427a1e8b37002d680b50903cc0))
- prevent looping mandatoryConfigKeys if skipValidation is present ([c690a57](https://github.com/currents-dev/currents-playwright-changelog/commit/c690a57db2d4463fbf8d7b38c687d3308f8f0cb4))
- remove unused debug initialization and console log in DefaultReporter ([79541b9](https://github.com/currents-dev/currents-playwright-changelog/commit/79541b90754456aaaa48dc9c22182e7298c35379))

### Features

- add remote debug artifact upload functionality and update reporter integration ([e72328a](https://github.com/currents-dev/currents-playwright-changelog/commit/e72328aeeb0707e63382b0c6b21b67329f2a05e4))
- use RemoteDebug class ([3ec3026](https://github.com/currents-dev/currents-playwright-changelog/commit/3ec30261436f345f0eafef2a8ba6a53044e1d1c5))

## [1.9.5-beta.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.9.4...v1.9.5-beta.0) (2025-02-23)

### Bug Fixes

- allow using currents config file with pwc-p ([c1c8be3](https://github.com/currents-dev/currents-playwright-changelog/commit/c1c8be399194b28c2c5c0686fdc1fcdd18feec06))
- init debug if config file defines it, arrange correct assertion for checking mandatory keys, restore load function ([f80f4a1](https://github.com/currents-dev/currents-playwright-changelog/commit/f80f4a125e0f981b8adb9424f8a0d6faf6bf0d14))
- move block to accept debug from reporter config, remove debug init from default reporter ([e728005](https://github.com/currents-dev/currents-playwright-changelog/commit/e7280053780699427a1e8b37002d680b50903cc0))
- prevent looping mandatoryConfigKeys if skipValidation is present ([c690a57](https://github.com/currents-dev/currents-playwright-changelog/commit/c690a57db2d4463fbf8d7b38c687d3308f8f0cb4))
- remove unused debug initialization and console log in DefaultReporter ([79541b9](https://github.com/currents-dev/currents-playwright-changelog/commit/79541b90754456aaaa48dc9c22182e7298c35379))

### Features

- add remote debug artifact upload functionality and update reporter integration ([e72328a](https://github.com/currents-dev/currents-playwright-changelog/commit/e72328aeeb0707e63382b0c6b21b67329f2a05e4))
- use RemoteDebug class ([3ec3026](https://github.com/currents-dev/currents-playwright-changelog/commit/3ec30261436f345f0eafef2a8ba6a53044e1d1c5))

## [1.9.4](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.9.3...v1.9.4) (2025-02-12)

### Bug Fixes

- add orchestration session creation timeout of 60 seconds ([7a3d419](https://github.com/currents-dev/currents-playwright-changelog/commit/7a3d419c5ea3ba9ef2883ec0d73a15c33f2a2ae6))
- add machineId parameter to getIntro method in OrchestrationPrinter ([c557d95](https://github.com/currents-dev/currents-playwright-changelog/commit/c557d9571dd51b323ad3168797f4764e9b8e3758))

## [1.9.3](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.9.2...v1.9.3) (2025-02-09)

### Bug Fixes

- allow using currents config file with pwc-p [CSR-2123] ([#348](https://github.com/currents-dev/currents-playwright-changelog/issues/348)) ([c768fe2](https://github.com/currents-dev/currents-playwright-changelog/commit/c768fe202942307d477a2abb2f1677566fed463b))

## [1.9.2](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.9.1...v1.9.2) (2025-02-05)

### Bug Fixes

- Truncate steps after we reach 2000 ([3496969](https://github.com/currents-dev/currents-playwright-changelog/commit/3496969dc26bd671e40a454783409900f371f677))

## [1.9.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.9.0...v1.9.1) (2024-12-27)

### Bug Fixes

- Only warn on coverage errors ([7ff08c4](https://github.com/currents-dev/currents-playwright-changelog/commit/7ff08c483eaec6ac646c5b122225f197ce3d1248))

# [1.9.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.9.0-beta.2...v1.9.0) (2024-12-16)

### Bug Fixes

- Allow disabling the currents fixtures ([8ed39d3](https://github.com/currents-dev/currents-playwright-changelog/commit/8ed39d31b6bb137683ee3c30560f329ea5786ef9))
- Fixture config load spam ([0192808](https://github.com/currents-dev/currents-playwright-changelog/commit/019280858f1d713fe6077463308b439ff6ebfddb))

# [1.9.0-beta.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.8.0...v1.9.0-beta.0) (2024-12-06)

### Bug Fixes

- Output discovery errors in orchestration ([52cc209](https://github.com/currents-dev/currents-playwright-changelog/commit/52cc209966aff0199e4387a5f425a741f286a111))

### Features

- Add a git info fixture that can be used in rules matching ([c186f54](https://github.com/currents-dev/currents-playwright-changelog/commit/c186f54f40bb5cfbbbfa0ddc121ff685746a549c))
- Standardize rules annotations ([a6c93de](https://github.com/currents-dev/currents-playwright-changelog/commit/a6c93decf8620fa23ebafe1ca5b5f0d775cdb730))
- Rename Rules to Actions ([#298](https://github.com/currents-dev/currents-playwright-changelog/issues/298)) ([a5778ba](https://github.com/currents-dev/currents-playwright-changelog/commit/a5778ba6f7623ece4fd5843f8e5f2210a6dc0fbd))

# [1.8.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.7.1...v1.8.0) (2024-11-25)

### Bug Fixes

- collect coverage when coverage.projects is an empty array ([c7066c2](https://github.com/currents-dev/currents-playwright-changelog/commit/c7066c2ea3545a726c236989bf227acd5b3468e6))

### Features

- Relicense under MIT ([#250](https://github.com/currents-dev/currents-playwright-changelog/issues/250)) ([1797b4c](https://github.com/currents-dev/currents-playwright-changelog/commit/1797b4cbbdf011e1f09e6372ea1aaa3384adf324))

## [1.7.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.7.0...v1.7.1) (2024-11-21)

### Bug Fixes

- Move msw back to being a dev package ([25ef14d](https://github.com/currents-dev/currents-playwright-changelog/commit/25ef14d0065c57131242ec96ab493f18ef8164d6))
- Use proper skip in quarantine so retires skip ([4980282](https://github.com/currents-dev/currents-playwright-changelog/commit/4980282c7694e4e720a02a9fbc80102d36108244))

# [1.7.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.7.0-beta.0...v1.7.0) (2024-11-19)

### Bug Fixes

- add coverage options to pwc-p program ([ef0c5e3](https://github.com/currents-dev/currents-playwright-changelog/commit/ef0c5e30302d791649f53cb9e7ec4ba662031ea7))
- tests ([b81a0a0](https://github.com/currents-dev/currents-playwright-changelog/commit/b81a0a01593a9329547fc08d2c9d8c66a1ef444a))
- typo ([e2aee5d](https://github.com/currents-dev/currents-playwright-changelog/commit/e2aee5d48dab05c11447d0358c4f60851efa8507))
- update config example ([b848e29](https://github.com/currents-dev/currents-playwright-changelog/commit/b848e29d6f72e8da4bcb2cf1a46059242e4a71a1))

* adding dependabot ([5a7210f](https://github.com/currents-dev/currents-playwright-changelog/commit/5a7210f0ed95ebb83eed98a9d7a2017b6f403bd9))
* use RULE_ANY_SYMBOL and RULE_NONE_SYMBOL ([41a5918](https://github.com/currents-dev/currents-playwright-changelog/commit/41a5918892be00a6902dff69c7d4fc9437ab8c8a))

### Features

- Add support for automation rules ([dfdf8e8](https://github.com/currents-dev/currents-playwright-changelog/commit/dfdf8e8b5fd60b47adee71083126ce17a5b2b1b1))
- Add support for coverage

## [1.6.2](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.6.1...v1.6.2) (2024-10-19)

### Bug Fixes

- add attachment type ([#209](https://github.com/currents-dev/currents-playwright-changelog/issues/209)) ([f1b540c](https://github.com/currents-dev/currents-playwright-changelog/commit/f1b540c0266cc603197b2e5a9c636dd436666bb4))

## [1.6.1](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.12...v1.6.1) (2024-10-15)

### Bug Fixes

- npm audit fix ([9184a5d](https://github.com/currents-dev/currents-playwright-changelog/commit/9184a5dd11fc9def9df27b805264059ac7d20345))
- typo ([6ac5996](https://github.com/currents-dev/currents-playwright-changelog/commit/6ac5996ff246cd93aa3f4cd2e6d98fa69641bc6a))

### Features

- send previousCiBuildId on run creation, if set ([48bfcd0](https://github.com/currents-dev/currents-playwright-changelog/commit/48bfcd0745c3d5501955435a6b1acb9f86d7eb70))
- show inline test url ([abb336f](https://github.com/currents-dev/currents-playwright-changelog/commit/abb336f005c8ee141763df4d5c2f2a5e8e8af5c0))

# [1.6.0](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.11...v1.6.0) (2024-09-20)

### Bug Fixes

- patch path-to-regexp ([9cf3d77](https://github.com/currents-dev/currents-playwright-changelog/commit/9cf3d77cfd75b66808f64279fb63d1ef2b17a86c))

### Features

- report orchestration status via onFinish ([c427461](https://github.com/currents-dev/currents-playwright-changelog/commit/c4274611b05801703fa910b95eca83b469ec18e6))
- use configuration from a config file ([cc29107](https://github.com/currents-dev/currents-playwright-changelog/commit/cc2910771bad5bd11952b2f2f8ddab4a7c5c0591))

## [1.5.12](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.11...v1.5.12) (2024-10-07)

### Bug Fixes

- retry on 500 ([124085f](https://github.com/currents-dev/currents-playwright-changelog/commit/124085f67019a3973b8db217eeb77406ad7a2982))

## [1.5.11](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.10...v1.5.11) (2024-09-09)

### Bug Fixes

- added support for only changed flag ([005347c](https://github.com/currents-dev/currents-playwright-changelog/commit/005347c8f9e9028579519f93088f0d96b2b592fb))
- moved cli only changed parsing to pwc-scanner ([3ba387a](https://github.com/currents-dev/currents-playwright-changelog/commit/3ba387ad30eef9364cd9ef2da63380faf9ccd5dc))

## [1.5.10](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.9...v1.5.10) (2024-09-02)

### Bug Fixes

- add debug info for orchestration ([#193](https://github.com/currents-dev/currents-playwright-changelog/issues/193)) ([739cc50](https://github.com/currents-dev/currents-playwright-changelog/commit/739cc504bb870c49f56f9cd45ce4ca902e4f46ff))

## [1.5.9](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.8...v1.5.9) (2024-08-28)

### Bug Fixes

- add --pwc-skip-reporter-injection ([31edb4d](https://github.com/currents-dev/currents-playwright-changelog/commit/31edb4d6a4c9d68f8c39a3b5a237cd5534f437f6))

## [1.5.8](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.6...v1.5.8) (2024-08-27)

### Bug Fixes

- Report flaky skipped tests rather than listing them as failed ([9d18b29](https://github.com/currents-dev/currents-playwright-changelog/commit/9d18b29bcb42c1cab16fe6ff617a31d7595037fe))

## [1.5.7](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.6...v1.5.7) (2024-08-26)

### Bug Fixes

- compress requests gt 1MB ([#184](https://github.com/currents-dev/currents-playwright-changelog/issues/184)) ([e5acd9d](https://github.com/currents-dev/currents-playwright-changelog/commit/e5acd9d7b6e73d34db5411d636b1bfb2d80c1fe8))
- limit error message and stack to 2048 chars ([#185](https://github.com/currents-dev/currents-playwright-changelog/issues/185)) ([4055a1d](https://github.com/currents-dev/currents-playwright-changelog/commit/4055a1d616939f991ef3e97239363b3e12509295))
- retry network requests on ENOTFOUND and EAI_AGAIN ([#186](https://github.com/currents-dev/currents-playwright-changelog/issues/186)) ([87a4df2](https://github.com/currents-dev/currents-playwright-changelog/commit/87a4df264320ee955a0a23b91f0b6e93acf95253))

## [1.5.6](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.5...v1.5.6) (2024-08-12)

### Bug Fixes

- add creation time for create requests ([5f440a2](https://github.com/currents-dev/currents-playwright-changelog/commit/5f440a24fc845333af7ace41b923a193f7ebc9e9))
- allow empty config ([56889fb](https://github.com/currents-dev/currents-playwright-changelog/commit/56889fba11b0435ac251cee879e3934088883cda))

## [1.5.5](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.4...v1.5.5) (2024-08-09)

### Bug Fixes

- clean up package.json before publishing ([dbb77df](https://github.com/currents-dev/currents-playwright-changelog/commit/dbb77dfa73cc483147e240522225bb24be8037aa))

## [1.5.4](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.3...v1.5.4) (2024-08-09)

### Bug Fixes

- change author filed to object ([1ddca8f](https://github.com/currents-dev/currents-playwright-changelog/commit/1ddca8fbe3df7ce0c3eb2e2f2d2e4f410dff3db2))

## [1.5.3](https://github.com/currents-dev/currents-playwright-changelog/compare/v1.5.2...v1.5.3) (2024-08-08)

### Bug Fixes

- added script to update changelog ([a08dc02](https://github.com/currents-dev/currents-playwright-changelog/commit/a08dc02eea836db0ebc4d037c63724ae3e9d929b))
- addressed feedback ([1272a5d](https://github.com/currents-dev/currents-playwright-changelog/commit/1272a5d4aae95134ddaf6e4ade726afc2952ca51))
- run changelog update on release and publish scripts ([f1ef130](https://github.com/currents-dev/currents-playwright-changelog/commit/f1ef13069ea48916705189ff6d7fb9481c552436))

## [1.5.2](https://github.com/currents-dev/currents-playwright/compare/v1.5.1...v1.5.2) (2024-08-01)

### Bug Fixes

- fix: retry failed request if path is /runs/v1 ([#177](https://github.com/currents-dev/currents-playwright/pull/177)) ([c6b334bd](https://github.com/currents-dev/currents-playwright/commit/c6b334bdbdc9ee156ae2b953ad599ea18e5d4cf4))
- fix: include apigw-requestid in error messages ([#177](https://github.com/currents-dev/currents-playwright/pull/177)) ([c6b334bd](https://github.com/currents-dev/currents-playwright/commit/c6b334bdbdc9ee156ae2b953ad599ea18e5d4cf4))

## [1.5.1](https://github.com/currents-dev/currents-playwright/compare/v1.5.0...v1.5.1) (2024-08-01)

### Bug Fixes

- send annotions with update request ([#178](https://github.com/currents-dev/currents-playwright/issues/178)) ([96ef74a](https://github.com/currents-dev/currents-playwright/commit/96ef74a3cce9dafadfdb69d30552250dadea74b1))

# [1.5.0](https://github.com/currents-dev/currents-playwright/compare/v1.4.6...v1.5.0) (2024-07-31)

### Bug Fixes

- Support the last-failed flag ([988c27a](https://github.com/currents-dev/currents-playwright/commit/988c27ac3567b42ac8d60fe25bb606a67c04b022))

### Features

- detect cancellation in or8n createTask ([644d8cf](https://github.com/currents-dev/currents-playwright/commit/644d8cf21ae21c8470acb50f943d8cac9c4557fb))

## [1.4.6](https://github.com/currents-dev/currents-playwright/compare/v1.4.5...v1.4.6) (2024-07-26)

### Bug Fixes

- show correct count of failed flaky tests ([2f26bd2](https://github.com/currents-dev/currents-playwright/commit/2f26bd2036ec98158e1a84ed0d63b40c283a525a))

## [1.4.5](https://github.com/currents-dev/currents-playwright/compare/v1.4.3...v1.4.5) (2024-07-10)

### Bug Fixes

- add CURRENTS_PWCP_DRY_RUN ([c2b6777](https://github.com/currents-dev/currents-playwright/commit/c2b6777eb07b0478064a02782deaaf7d4c4564f7))

## [1.4.4](https://github.com/currents-dev/currents-playwright/compare/v1.4.4...v1.4.3) (2024-06-25)

### Misc

- pwc: Auto generate ciBuildId when not detected

## [1.4.3](https://github.com/currents-dev/currents-playwright/compare/v1.4.3-beta.1...v1.4.3) (2024-06-25)

### Bug Fixes

- use proxy-from-env ([10816fa](https://github.com/currents-dev/currents-playwright/commit/10816fa9bb107ad7103b0fd6c6dfe5a9d6a11ddb))
- use https-proxy-agent ([3da0e47](https://github.com/currents-dev/currents-playwright/commit/3da0e475d622df72b4fa0333bd1f4ec798a2c68c))

### Misc

- update dependencies to patch vulnerabilities

## [1.4.3-beta.1](https://github.com/currents-dev/currents-playwright/compare/v1.4.3-beta.0...v1.4.3-beta.1) (2024-06-24)

### Bug Fixes

- use proxy for uploads ([75aa154](https://github.com/currents-dev/currents-playwright/commit/75aa154227736169452c0d0627d4b3e82104bba7))

## [1.4.3-beta.0](https://github.com/currents-dev/currents-playwright/compare/v1.4.1...v1.4.3-beta.0) (2024-06-24)

### Bug Fixes

- use https-proxy-agent ([3da0e47](https://github.com/currents-dev/currents-playwright/commit/3da0e475d622df72b4fa0333bd1f4ec798a2c68c))

## [1.4.2](https://github.com/currents-dev/currents-playwright/compare/v1.4.1...v1.4.2) (2024-06-21)

### Bug Fixes

- Arg parsing side-effect that was duplicating tests CSR-1276 ([#170](https://github.com/currents-dev/currents-playwright/issues/170)) ([05cfd4b](https://github.com/currents-dev/currents-playwright/commit/05cfd4b80a89f547a1a36951e34a9586fb54cb54))

## [1.4.1](https://github.com/currents-dev/currents-playwright/compare/v1.4.0...v1.4.1) (2024-06-18)

### Bug Fixes

- move to config function and set in onBegin ([60bbe2a](https://github.com/currents-dev/currents-playwright/commit/60bbe2a553ee300c3c49b5527f30bcfa4c1b3308))
- remove warning from discovery reporter and add it to orchestration reporter ([18a9030](https://github.com/currents-dev/currents-playwright/commit/18a90303db5d26d9ced761c7761355396d970e92))

# [1.4.0](https://github.com/currents-dev/currents-playwright/compare/v1.3.3...v1.4.0) (2024-06-10)

### Features

- Enable passing additional reporters on the cli ([#164](https://github.com/currents-dev/currents-playwright/issues/164)) ([07e9bee](https://github.com/currents-dev/currents-playwright/commit/07e9bee8a78088479268a6db833305d1e88f52ca))

### Bug Fixes

- Allow pwc-p to read config from the environment ([#160](https://github.com/currents-dev/currents-playwright/issues/160)) ([47effc3](https://github.com/currents-dev/currents-playwright/commit/47effc37aa3c06ca2629613118f1434f454c0122))
- drop sourcemaps-support register for reporters ([#165](https://github.com/currents-dev/currents-playwright/issues/165)) ([70174bf](https://github.com/currents-dev/currents-playwright/commit/70174bf1b0572a672d053c998bf5e04bcdf21d1a))

## [1.3.3](https://github.com/currents-dev/currents-playwright/compare/v1.3.2...v1.3.3) (2024-06-03)

### Bug Fixes

- fullConfig finding failed in playwright v1.32 and below ([d09e946](https://github.com/currents-dev/currents-playwright/commit/d09e946b22268daae4e6c0d5570fc8163fb238bd))

## [1.3.2](https://github.com/currents-dev/currents-playwright/compare/v1.3.1...v1.3.2) (2024-05-29)

### Bug Fixes

- filter playwright options from undesired arguments ([e6e412d](https://github.com/currents-dev/currents-playwright/commit/e6e412df7e4f28ceb580dee7b069ed7bdc611f39))

## [1.3.1](https://github.com/currents-dev/currents-playwright/compare/v1.3.0...v1.3.1) (2024-05-17)

### Bug Fixes

- pwc-p - don't allow task groupId to be overridden by cli args ([e727f5b](https://github.com/currents-dev/currents-playwright/commit/e727f5b8bb552fac423d4bbbc54b45a9130807a0))
- use -- to separate the playwright command cli options and arguments ([8ea7078](https://github.com/currents-dev/currents-playwright/commit/8ea7078b1d68a6ccca90908a00f1d3fb2733579c))

# [1.3.0](https://github.com/currents-dev/currents-playwright/compare/v1.1.8...v1.3.0) (2024-05-16)

### Bug Fixes

- add --repeat-each to scanner args ([2ad9d16](https://github.com/currents-dev/currents-playwright/commit/2ad9d16fa4c13461ddaf34ae5ab194b7f8b49aa0))

### Features

- Support --pwc-reset-signal for resetting machine specs [CSR-1152] ([#153](https://github.com/currents-dev/currents-playwright/issues/153)) ([ab38e51](https://github.com/currents-dev/currents-playwright/commit/ab38e515039c5e112a3541ff44cea32bef6c9114)), closes [#157](https://github.com/currents-dev/currents-playwright/issues/157)

# [1.2.0](https://github.com/currents-dev/currents-playwright/compare/v1.2.0-beta.0...v1.2.0) (2024-05-03)

# [1.2.0-beta.0](https://github.com/currents-dev/currents-playwright/compare/v1.1.8...v1.2.0-beta.0) (2024-05-03)

### Features

- add --pwc-output-file for JSON output [CSR-1157] ([#151](https://github.com/currents-dev/currents-playwright/issues/151)) ([f3626d0](https://github.com/currents-dev/currents-playwright/commit/f3626d057748fd3a9b525c6c2a5ff5d29eedaff7))

## [1.1.9](https://github.com/currents-dev/currents-playwright/compare/v1.1.8...v1.1.9) (2024-04-30)

## [1.1.9-alpha.0](https://github.com/currents-dev/currents-playwright/compare/v1.1.8...v1.1.9-alpha.0) (2024-04-30)

### Bug Fixes

- add lodash as a dep for scanner [skip ci] ([c7ec06b](https://github.com/currents-dev/currents-playwright/commit/c7ec06bc9b2a09bed6168c6adeb87c90a9e556ef))

## [1.1.8](https://github.com/currents-dev/currents-playwright/compare/v1.1.7...v1.1.8) (2024-04-26)

### Bug Fixes

- add "tmp" module dependecy ([#146](https://github.com/currents-dev/currents-playwright/issues/146)) ([5561a04](https://github.com/currents-dev/currents-playwright/commit/5561a04f13de37ca6cc29ddaaed418a2b0f5af69))

## [1.1.7](https://github.com/currents-dev/currents-playwright/compare/v1.1.6...v1.1.7) (2024-04-18)

### Bug Fixes

- Use the correct spec file location ([9dbefcb](https://github.com/currents-dev/currents-playwright/commit/9dbefcb3547acd9ba4ca758e4b0ba2b05f47091a))

## [1.1.6](https://github.com/currents-dev/currents-playwright/compare/v1.1.5...v1.1.6) (2024-04-09)

### Bug Fixes

- use pwc-scanner@0.1.0 [skip ci] ([1918036](https://github.com/currents-dev/currents-playwright/commit/1918036ece840f44373fe3a013838779eef87d08))
- generate name for projects with an empty name or undefined name
- forbid orchestration for unnamed projects

## [1.1.5](https://github.com/currents-dev/currents-playwright/compare/v1.1.4...v1.1.5) (2024-04-05)

### Bug Fixes

- don't throw when there is missing instanceId ([767eb45](https://github.com/currents-dev/currents-playwright/commit/767eb45f2a46b4ff0606c6ee439f086dd0d9f207))

## [1.1.4](https://github.com/currents-dev/currents-playwright/compare/v1.1.3...v1.1.4) (2024-04-03)

## [1.1.3](https://github.com/currents-dev/currents-playwright/compare/v1.1.2...v1.1.3) (2024-04-03)

### Bug Fixes

- fix widnows paths for fullTestSuite ([9d3e56e](https://github.com/currents-dev/currents-playwright/commit/9d3e56e138f8b0a357e20328936333b8f0b2aa39))

## [1.1.2](https://github.com/currents-dev/currents-playwright/compare/v1.1.0...v1.1.2) (2024-04-01)

### Bug Fixes

- @currents/pwc-scanner@0.0.4 ([9d2fef1](https://github.com/currents-dev/currents-playwright/commit/9d2fef1803038f0c69d5d76a32af69ad396540a1))

## [1.1.1](https://github.com/currents-dev/currents-playwright/compare/v1.1.0...v1.1.1) (2024-04-01)

### Bug Fixes

- fix a bug with explicit projects for the same ci-build-id ([92cb0db](https://github.com/currents-dev/currents-playwright/commit/92cb0dba392e39cd5f260b41a21fe6053e02a480))
- fix a bug with ignoring --grep-invert for discovering full testing suite, add context for debug ([1766c01](https://github.com/currents-dev/currents-playwright/commit/1766c017bcdeef6df71551d5215dd593f19bdefd))
- consider .only for discovering full testing suite ([1ac74fe](https://github.com/currents-dev/currents-playwright/commit/1ac74fe27066210407f22e3698bbaf41020b76f7))

# [1.1.0](https://github.com/currents-dev/currents-playwright/compare/v1.0.1...v1.1.0) (2024-03-27)

### Features

- Pipeline url information from azure ([#137](https://github.com/currents-dev/currents-playwright/issues/137)) ([0c022ac](https://github.com/currents-dev/currents-playwright/commit/0c022acce2febf92f14106fde91a2a7593de7cf0))

## [1.0.1](https://github.com/currents-dev/currents-playwright/compare/v0.12.2...v1.0.1) (2024-03-26)

### Features

This is a major revamp of the reporter. There are **no breaking changes** in terms of API and configuration, but there are significant changes in the underlying reporting mechanism and the produced output.

- **Full parallel mode support**: set `fullyParallel: true` to enable running individual tests from the [same spec file on different workers](https://playwright.dev/docs/api/class-testproject#test-project-fully-parallel). Playwright supports multiple levels of concurrency - a test suite can be split between different machines using sharding, and on each individual machine Playwright will spawn parallel workers (according to CPU performance or explicit configuration). The workers will run in parallel, executing the tests (or more precisely, test attempts). By default, Playwright runs the tests of the same spec file serially one after another, but, if the tests are isolated, enabling `fullyParallel: true` will allow running tests from the same spec file in parallel on different workers (or sometimes even on different shards / machines). The most recent version of the reporter is compatible with full parallel mode and will collect the results of concurrent parallel executions.

- **Step-level reporting**: playwright organizes tests executions according to the following hierarchy: Run > Project > Spec File > Test > Attempt > Step. Traditionally, reporters send the results **after** Run completion (sometimes after Spec File completion). It works well in most cases, but.... imagine running a spec file with 10 tests on a CI machine. 9 tests can be completed successfully, but the last test can cause a crash. If we report **after** spec completion, no results will be reported at all, even for 9 completed test. Currents reporter sends the results for each individual step (with some batching applied for better performance). That allows capturing as much information as possible as soon as it's ready. It is super-valuable for debugging failed CI executions, which are often unique and are not easy to reproduce locally.

- **Reporter output and results**: we have refactored the look and the feel of the reporter's console output for more precise and accurate presentation of the execution workflow. A test execution consists of one or more attempts, each attempt can have its own status, errors, stdout and stderr output. [Determining](https://docs.currents.dev/tests/test-status#playwright-test-status) a test's "status" and flakiness requires considering the outcome of all the attempts, the expected status and the execution mode (e.g. ["serial" mode](https://playwright.dev/docs/test-parallel#serial-mode) can generate extra attempts). The new format makes it easier to track the logic behind determining test status, displays individual attempts errors. Additionally, we split the captured output, that can have mixed items from concurrent parallel workers and assign them to the corresponding spec files.

- **Playwright orchestration**: the new CLI tool `pwc-p` improves Playwright CI executions by automatically balancing spec files between CI machines. The balancing uses the data from the previously recorded executions to optimally assign spec files between machines, which allows up to 40% decrease in CI E2E Playwright tests. Please refer to our documentation for more details and instructions.

## [0.12.2](https://github.com/currents-dev/currents-playwright/compare/v0.12.1...v0.12.2) (2024-03-06)

### Bug Fixes

- handle teamcity git params ([56ad8fc](https://github.com/currents-dev/currents-playwright/commit/56ad8fc9fa5896001d62dbb176ba14052a3c42a9))

## [0.12.1](https://github.com/currents-dev/currents-playwright/compare/v0.12.0...v0.12.1) (2024-02-05)

### Bug Fixes

- use proper debug fn for cancellation ([a5cc5c1](https://github.com/currents-dev/currents-playwright/commit/a5cc5c11e4c21f4ec681356f72b42c5bda9edb39))

# [0.12.0](https://github.com/currents-dev/currents-playwright/compare/v0.11.5...v0.12.0) (2024-01-30)

### Features

- Collect GitHub Actions PR information ([7229ac](https://github.com/currents-dev/currents-playwright/commit/7229acd8ae48d2bf34f653be4bf9bfdfd682d3a0))

### Features

- add scanner package, wip ([3195de4](https://github.com/currents-dev/currents-playwright/commit/3195de499912956d7911a41c30c56923f1552376))

## [0.11.5](https://github.com/currents-dev/currents-playwright/compare/v0.11.5-beta.0...v0.11.5) (2023-12-17)

### Bug Fixes

- report non-run tests and attempts as skipped ([dc22305](https://github.com/currents-dev/currents-playwright/commit/dc2230526ee6c7ed9c7f13a90e43de393aaf62e4))

## [0.11.4](https://github.com/currents-dev/currents-playwright/compare/v0.11.3...v0.11.4) (2023-12-11)

## [0.11.3](https://github.com/currents-dev/currents-playwright/compare/v0.11.3-beta.1...v0.11.3) (2023-12-11)

### Bug Fixes

- add remote debugging ([6db1329](https://github.com/currents-dev/currents-playwright/commit/6db13291fafdbc30eb0e70ad6c56de9591c1e735))

## [0.11.2](https://github.com/currents-dev/currents-playwright/compare/v0.11.1...v0.11.2) (2023-12-05)

### Bug Fixes

- exit with zero when no tests detected ([459af9e](https://github.com/currents-dev/currents-playwright/commit/459af9e1570d1675f6b390cd546e5152a0771d7f))

## [0.11.1](https://github.com/currents-dev/currents-playwright/compare/v0.11.0...v0.11.1) (2023-12-01)

### Bug Fixes

- fix cli description ([a8b95b7](https://github.com/currents-dev/currents-playwright/commit/a8b95b74b884401b92b139d4e1ffc8ba7d371568))

# [0.11.0](https://github.com/currents-dev/currents-playwright/compare/v0.11.0-beta.0...v0.11.0) (2023-12-01)

### Bug Fixes

- handle cloud error messages ([c978e9f](https://github.com/currents-dev/currents-playwright/commit/c978e9f05579739df9499604eac0810f9394374c))
- reporter to return run actual status ([3727167](https://github.com/currents-dev/currents-playwright/commit/372716719afd1d31e2d9875b7df917c4a17ac83d))

### Features

- implement cancelAfterFailures and disableTitleTags ([452e666](https://github.com/currents-dev/currents-playwright/commit/452e666b741ea84c216c745b22a4d35a65307ab4))

## [0.10.9](https://github.com/currents-dev/currents-playwright/compare/v0.10.8...v0.10.9) (2023-11-23)

### Bug Fixes

- change doc link ([6d4aacc](https://github.com/currents-dev/currents-playwright/commit/6d4aaccbfa35d956483a580b2580ddb3b6f789d9))

## [0.10.8](https://github.com/currents-dev/currents-playwright/compare/v0.10.8-beta.0...v0.10.8) (2023-11-22)

### Bug Fixes

- set status and flaks based on pw outcome ([2bcec5e](https://github.com/currents-dev/currents-playwright/commit/2bcec5ee12ededa30244ef604c93b63640ab939b))

- handle serial mode ([9499528](https://github.com/currents-dev/currents-playwright/commit/9499528706ee2fe6cfe474ecb4c7578cab3c0fe5))

## [0.10.7](https://github.com/currents-dev/currents-playwright/compare/v0.10.6...v0.10.7) (2023-11-20)

### Bug Fixes

- add commander as a dependency ([f00191b](https://github.com/currents-dev/currents-playwright/commit/f00191b3509d7dd47c292ac11b0ef5c31994eaf0))

## [0.10.6](https://github.com/currents-dev/currents-playwright/compare/v0.10.5...v0.10.6) (2023-11-07)

### Bug Fixes

- use @currents/commit-info ([b737211](https://github.com/currents-dev/currents-playwright/commit/b73721163ec1921fca05eda71111e1abe9a59283))

## [0.10.5](https://github.com/currents-dev/currents-playwright/compare/v0.10.4...v0.10.5) (2023-11-07)

### Bug Fixes

- remove \_pwc-parallel because of pnpm error ([6f9c785](https://github.com/currents-dev/currents-playwright/commit/6f9c785e475f4e78ffcf1dd08b1c5ca7f7beeacf))

## [0.10.4](https://github.com/currents-dev/currents-playwright/compare/v0.10.3...v0.10.4) (2023-11-04)

### Bug Fixes

- remove log message ([8dea731](https://github.com/currents-dev/currents-playwright/commit/8dea73149ffefc6ec283ba543bd5469292e845dd))

## [0.10.3](https://github.com/currents-dev/currents-playwright/compare/v0.10.2...v0.10.3) (2023-11-04)

### Bug Fixes

- make reporterOptions optional ([b497249](https://github.com/currents-dev/currents-playwright/commit/b497249b38d4da16f8d63fa79a5953e960396f50))

## [0.10.2](https://github.com/currents-dev/currents-playwright/compare/v0.10.1...v0.10.2) (2023-11-02)

### Bug Fixes

- report tests for single project ([de6448e](https://github.com/currents-dev/currents-playwright/commit/de6448efebbb59cc35f86297b88250bc35c6bb12))

## [0.10.1](https://github.com/currents-dev/currents-playwright/compare/v0.10.0...v0.10.1) (2023-10-31)

### Bug Fixes

- add missing deps ([9c9e875](https://github.com/currents-dev/currents-playwright/commit/9c9e875d5f8cda7a9327df582f952aa8c3f7fefe))

# [0.10.0](https://github.com/currents-dev/currents-playwright/compare/v0.10.0-beta.2...v0.10.0) (2023-10-31)

### Bug Fixes

- make non-mandatory config optional ([f6b8dcd](https://github.com/currents-dev/currents-playwright/commit/f6b8dcdba50b299039f91bc5e232f75db1101270))

- detect build id in CI ([efcf50d](https://github.com/currents-dev/currents-playwright/commit/efcf50de2e82225e9f276a5d635dbdc66af5c5c2))

### Features

- add --pwc-remove-title-tags ([e842bdb](https://github.com/currents-dev/currents-playwright/commit/e842bdbd7412c5423455610f3c60b5e5af6040df))
- refactor CLI processing ([c5f4977](https://github.com/currents-dev/currents-playwright/commit/c5f49770ca94c20f5fb226748916c2e606f60cee))
- support tags in project metadata ([b11ee9c](https://github.com/currents-dev/currents-playwright/commit/b11ee9cfac44d367f08cf4283a72efc305d61564))

# [0.9.0](https://github.com/currents-dev/currents-playwright/compare/v0.8.1...v0.9.0) (2023-10-20)

### Features

- implement cancellations ([f9bcad0](https://github.com/currents-dev/currents-playwright/commit/f9bcad0f9617988b4e77a47f6804a362c0013422))

### Bug Fixes

- check cancellation for existing runs ([f9bcad0](https://github.com/currents-dev/currents-playwright/commit/f9bcad0f9617988b4e77a47f6804a362c0013422))
- remove useless try...catch block ([46c4403](https://github.com/currents-dev/currents-playwright/commit/46c440300864659f07302143772be4a7e8d414e9))

## [0.8.1](https://github.com/currents-dev/currents-playwright/compare/v0.8.0...v0.8.1) (2023-09-07)

### Bug Fixes

- redact attachments body ([cf6c757](https://github.com/currents-dev/currents-playwright/commit/cf6c757ab02dd4b668ec159808d3049a50d03ba6))

# [0.8.0](https://github.com/currents-dev/currents-playwright/compare/v0.7.2...v0.8.0) (2023-09-07)

### Features

- test-level report ([9797b7a](https://github.com/currents-dev/currents-playwright/commit/9797b7ac68d0fe3e8627058c2e791134f6943345))

## [0.7.2](https://github.com/currents-dev/currents-playwright/compare/v0.7.1...v0.7.2) (2023-08-23)

### Bug Fixes

- capture error details ([7fbcacd](https://github.com/currents-dev/currents-playwright/commit/7fbcacd80cf7649d0a1676628aaf03cd80ca1acb))

## [0.7.1](https://github.com/currents-dev/currents-playwright/compare/v0.7.0...v0.7.1) (2023-08-16)

# [0.7.0](https://github.com/currents-dev/currents-playwright/compare/v0.6.4...v0.7.0) (2023-08-16)

### Features

- implement tags ([3ac3bf1](https://github.com/currents-dev/currents-playwright/commit/3ac3bf12696698d908adc032cb061164374d34ea))

## [0.6.4](https://github.com/currents-dev/currents-playwright/compare/v0.6.0...v0.6.4) (2023-08-09)

### Bug Fixes

- add debug message for execa ([d94e49f](https://github.com/currents-dev/currents-playwright/commit/d94e49fa264320eb17fda919a040c714cfcca0c2))
- add execa ([4158356](https://github.com/currents-dev/currents-playwright/commit/415835689d6c0a7aab73278e97983e8895a4e22b))

## [0.6.4-beta.0](https://github.com/currents-dev/currents-playwright/compare/v0.6.0...v0.6.4-beta.0) (2023-07-29)

### Bug Fixes

- add execa ([4158356](https://github.com/currents-dev/currents-playwright/commit/415835689d6c0a7aab73278e97983e8895a4e22b))

## [0.6.3](https://github.com/currents-dev/currents-playwright/compare/v0.6.0...v0.6.3) (2023-07-12)

### Bug Fixes

- report errors for hooks and internal steps ([1ce1d89](https://github.com/currents-dev/currents-playwright/commit/1ce1d89eaf23d55f36a57265eab084f30f920744))

## [0.6.2](https://github.com/currents-dev/currents-playwright/compare/v0.6.0...v0.6.2) (2023-06-30)

### Bug Fixes

- set pw version ([89468b2](https://github.com/currents-dev/currents-playwright/commit/89468b2fe173a49472e1aa6e9578786a4a1ae8d7))
- specify content-type and disposition ([d9ba3e3](https://github.com/currents-dev/currents-playwright/commit/d9ba3e3424b7c848d37fb3ecd1abb32ed6795d4e))
- support multiple videos ([10d10f9](https://github.com/currents-dev/currents-playwright/commit/10d10f9f997c889e0ead45e3d76b90ca84f406b2))

## [0.6.1](https://github.com/currents-dev/currents-playwright/compare/v0.6.0...v0.6.1) (2023-06-30)

### Bug Fixes

- set pw version ([89468b2](https://github.com/currents-dev/currents-playwright/commit/89468b2fe173a49472e1aa6e9578786a4a1ae8d7))
- specify content-type and disposition ([d9ba3e3](https://github.com/currents-dev/currents-playwright/commit/d9ba3e3424b7c848d37fb3ecd1abb32ed6795d4e))
- support multiple videos ([10d10f9](https://github.com/currents-dev/currents-playwright/commit/10d10f9f997c889e0ead45e3d76b90ca84f406b2))

# [0.6.0](https://github.com/currents-dev/currents-playwright/compare/v0.5.0...v0.6.0) (2023-06-15)

### Bug Fixes

- report pwc version ([c3745a2](https://github.com/currents-dev/currents-playwright/commit/c3745a2f7502c5695775cda1d82c64a36a152f1c))
- send workerId information ([fe29eb5](https://github.com/currents-dev/currents-playwright/commit/fe29eb5e9e072effe65de517d6964d38590b9f4e))

### Features

- send workerIndex and parallelIndex ([c392a41](https://github.com/currents-dev/currents-playwright/commit/c392a41544679305ab12d229b6973cb8dfe1acfa))

# [0.5.0](https://github.com/currents-dev/currents-playwright/compare/v0.5.0-beta.2...v0.5.0) (2023-06-11)

# [0.5.0-beta.2](https://github.com/currents-dev/currents-playwright/compare/v0.5.0-beta.1...v0.5.0-beta.2) (2023-06-08)

### Bug Fixes

- remove playwright from peer deps ([755148e](https://github.com/currents-dev/currents-playwright/commit/755148ea47bc5c909e15a01e00948b5ed2f114e8))

# [0.5.0-beta.1](https://github.com/currents-dev/currents-playwright/compare/0.5.0-beta.0...v0.5.0-beta.1) (2023-06-08)

# [0.5.0-beta.0](https://github.com/currents-dev/currents-playwright/compare/0.4.2...0.5.0-beta.0) (2023-06-08)

### Features

- support image buffers
- upload console output directly to remote storage
- better error messages ([f87a5a9](https://github.com/currents-dev/currents-playwright/commit/f87a5a9a0a706f74290afe5802cd37f193de6b7e))

### Bug Fixes

- show warning received from cloud service
- handle screenshot buffers ([d24b9ab](https://github.com/currents-dev/currents-playwright/commit/d24b9abe07990fa366b0d6d1337184d9c9bb0ae2))
- reduce payload size ([a7b3ed7](https://github.com/currents-dev/currents-playwright/commit/

## [0.4.2](https://github.com/currents-dev/currents-playwright/compare/0.4.1...0.4.2) (2023-05-12)

### Bug Fixes

- fix npm dependencies ([608cd53](https://github.com/currents-dev/currents-playwright/commit/608cd53fa60999fe60f07fe611cca3dfd250a13a))

## [0.4.1](https://github.com/currents-dev/currents-playwright/compare/0.4.0...0.4.1) (2023-05-09)

### Bug Fixes

- fallback to \_id for testCase ([923e7e9](https://github.com/currents-dev/currents-playwright/commit/923e7e9f109802c16e36353f31a2c53387e1d2b3))

# [0.4.0](https://github.com/currents-dev/currents-playwright/compare/0.3.8-beta.0...0.4.0) (2023-05-05)

### Bug Fixes

- allow debugging extensions ([17b5a5f](https://github.com/currents-dev/currents-playwright/commit/17b5a5f0047df8b4fa610b07d47a88a71be34a7d))
- send ciBuildId when creating a run ([d47a2c1](https://github.com/currents-dev/currents-playwright/commit/d47a2c176b308e842eaf67439679354cee82a073))
- show upload warnings at the end of execution ([63c91f3](https://github.com/currents-dev/currents-playwright/commit/63c91f33cc253ef432236e1664a644df40d4a5c1))
- upload stdout and artifacts in parallel ([10a0d2d](https://github.com/currents-dev/currents-playwright/commit/10a0d2d891a1a0c71dccfb7842a37089e26b5647))
- use debug extensions ([0512596](https://github.com/currents-dev/currents-playwright/commit/05125960e25fb532824d268c1a46e82682faa163))

### Features

- refactor + stabilize network uploads ([1f945b6](https://github.com/currents-dev/currents-playwright/commit/1f945b6168e601e0f1f48cf1e4bfd64fd0ee3e25))
- refactor + stabilize network uploads ([1b1cbe9](https://github.com/currents-dev/currents-playwright/commit/1b1cbe9cf136efb056299b257e88fba31fdb2a68))

## [0.3.8-beta.0](https://github.com/currents-dev/currents-playwright/compare/0.3.7...0.3.8-beta.0) (2023-04-20)

### Bug Fixes

- use network retries, enhance debugging ([f996250](https://github.com/currents-dev/currents-playwright/commit/f996250a3b52ade75e0a676c31d50153c2c12b8b))

## [0.3.7](https://github.com/currents-dev/currents-playwright/compare/0.3.6...0.3.7) (2023-04-11)

### Bug Fixes

- send raw results for troubleshooting ([712cf7e](https://github.com/currents-dev/currents-playwright/commit/712cf7e0865ea3fc7488aa8fb01c0fde8db8fde6))

## [0.3.6](https://github.com/currents-dev/currents-playwright/compare/0.3.5...0.3.6) (2023-04-10)

### Bug Fixes

- handle expected vs actual tests status ([6d3c5cb](https://github.com/currents-dev/currents-playwright/commit/6d3c5cb18d1cad94f856eb37fa10cacf0d13ac89))

## [0.3.5](https://github.com/currents-dev/currents-playwright/compare/0.3.4...0.3.5) (2023-03-31)

### Bug Fixes

- use execa to support windows ([b20b746](https://github.com/currents-dev/currents-playwright/commit/b20b746c08f04f8d714d4d39eae49c86387ffc8f))

## [0.3.4](https://github.com/currents-dev/currents-playwright/compare/0.3.3...0.3.4) (2023-02-20)

### Bug Fixes

- wait for flaky test to complete ([95fffef](https://github.com/currents-dev/currents-playwright/commit/95fffef93522391ad665e14841a976fe61da747e))

## [0.3.3](https://github.com/currents-dev/currents-playwright/compare/0.3.2...0.3.3) (2023-02-08)

## [0.3.2](https://github.com/currents-dev/currents-playwright/compare/0.3.1...0.3.2) (2023-02-08)

### Bug Fixes

- handle empty results ([ac09874](https://github.com/currents-dev/currents-playwright/commit/ac098748be6cf135c829b9e3694e19f87ea120ae))

## [0.3.1](https://github.com/currents-dev/currents-playwright/compare/0.3.0...0.3.1) (2023-02-06)

### Bug Fixes

- remove requiring pw+pwc version ([9481736](https://github.com/currents-dev/currents-playwright/commit/9481736139dc96a781bd8103d9fac8651c422b92))

# [0.3.0](https://github.com/currents-dev/currents-playwright/compare/0.2.2...0.3.0) (2023-02-06)

### Bug Fixes

- exist with pw's exit status ([983bb0c](https://github.com/currents-dev/currents-playwright/commit/983bb0c3aece981c6c28fd2f36b2fdef63320d20))
- handle expired run case ([5d008cf](https://github.com/currents-dev/currents-playwright/commit/5d008cfc881c70d5c6471c5032654cabcee14606))
- use claimedCount > 1 ([ee40f1e](https://github.com/currents-dev/currents-playwright/commit/ee40f1e01ff9f17468a1cb975a45456ca3fe8ba0))
- use dedicated pw stdout endpoint ([62f4a48](https://github.com/currents-dev/currents-playwright/commit/62f4a481cbef8e93d1a500942d5df84cca9379dd))
- use PR ref for clear message ([3c7e6a6](https://github.com/currents-dev/currents-playwright/commit/3c7e6a671d4eb8dd6883f0c86e93db3b6c6c6e5e))

### Features

- upload results and stdout in parallel ([4e7e165](https://github.com/currents-dev/currents-playwright/commit/4e7e1657e6a3be03ab697e24b28f2d8e3966dbfe))
- upload results in 1 requests ([93053d1](https://github.com/currents-dev/currents-playwright/commit/93053d19ca6d3391a7df11c29b7edc8e0745d751))

## [0.2.2](https://github.com/currents-dev/currents-playwright/compare/0.2.0...0.2.2) (2023-01-31)

### Bug Fixes

- skip uploading results for errors ([dd0d3a8](https://github.com/currents-dev/currents-playwright/commit/dd0d3a8122f66b305cb94341b35515eac84e5033))

# [0.2.0](https://github.com/currents-dev/currents-playwright/compare/0.1.1...0.2.0) (2023-01-31)

### Bug Fixes

- fix counting repeated tests and their status ([f24694a](https://github.com/currents-dev/currents-playwright/commit/f24694a4d961dd655af4938bcbed45c97ae8a5dd))

### Features

- add http errors handlers ([044a93f](https://github.com/currents-dev/currents-playwright/commit/044a93f93c3c351c69abe220c1596ecf762840a0))
- create instances in advance ([830064b](https://github.com/currents-dev/currents-playwright/commit/830064bb7d501162d26da2bc03b61f36d5d30de2))
- upload results in parallel ([b6f3179](https://github.com/currents-dev/currents-playwright/commit/b6f3179db2dfe4a3d8ce61cbceffae892275dfc2))

## [0.1.1](https://github.com/currents-dev/currents-playwright/compare/0.1.0...0.1.1) (2023-01-26)

# [0.1.0](https://github.com/currents-dev/currents-playwright/compare/f50c00cd0eff6c10728daae8577a1e80d35c5c34...0.1.0) (2023-01-26)

### Bug Fixes

- "skipped" > "pending". Closes [#28](https://github.com/currents-dev/currents-playwright/issues/28) ([96611fe](https://github.com/currents-dev/currents-playwright/commit/96611feab062329e6394acb3ac5fb17c3d0576f2))
- various fixes from local testing ([ace1782](https://github.com/currents-dev/currents-playwright/commit/ace1782a0030203ccbd818b68dc9a3e7fbf06299))

### Features

- add basic Playwright reporter ([f50c00c](https://github.com/currents-dev/currents-playwright/commit/f50c00cd0eff6c10728daae8577a1e80d35c5c34))
- create run on onBegin ([a30c33c](https://github.com/currents-dev/currents-playwright/commit/a30c33c62425920c424551a85d7f966866178dc7))
- get git info in test reporter ([845c83d](https://github.com/currents-dev/currents-playwright/commit/845c83dcb4fb4a5d9a8f740026d1fdddede9f06b))
- make initial setup call from Playwright ([ac5083b](https://github.com/currents-dev/currents-playwright/commit/ac5083bb3c1d585293d090fc6475eb173373ecab))
- sent version headers with network requests ([3ad1896](https://github.com/currents-dev/currents-playwright/commit/3ad1896c239c944ed657a471eeb6e07ea80b762e))

# [0.4.0](https://github.com/currents-dev/currents-playwright/compare/0.3.8-beta.0...0.4.0) (2023-05-05)

### Bug Fixes

- allow debugging extensions ([17b5a5f](https://github.com/currents-dev/currents-playwright/commit/17b5a5f0047df8b4fa610b07d47a88a71be34a7d))
- send ciBuildId when creating a run ([d47a2c1](https://github.com/currents-dev/currents-playwright/commit/d47a2c176b308e842eaf67439679354cee82a073))
- show upload warnings at the end of execution ([63c91f3](https://github.com/currents-dev/currents-playwright/commit/63c91f33cc253ef432236e1664a644df40d4a5c1))
- upload stdout and artifacts in parallel ([10a0d2d](https://github.com/currents-dev/currents-playwright/commit/10a0d2d891a1a0c71dccfb7842a37089e26b5647))
- use debug extensions ([0512596](https://github.com/currents-dev/currents-playwright/commit/05125960e25fb532824d268c1a46e82682faa163))

### Features

- refactor + stabilize network uploads ([1f945b6](https://github.com/currents-dev/currents-playwright/commit/1f945b6168e601e0f1f48cf1e4bfd64fd0ee3e25))
- refactor + stabilize network uploads ([1b1cbe9](https://github.com/currents-dev/currents-playwright/commit/1b1cbe9cf136efb056299b257e88fba31fdb2a68))

## [0.3.8-beta.0](https://github.com/currents-dev/currents-playwright/compare/0.3.7...0.3.8-beta.0) (2023-04-20)

### Bug Fixes

- use network retries, enhance debugging ([f996250](https://github.com/currents-dev/currents-playwright/commit/f996250a3b52ade75e0a676c31d50153c2c12b8b))

## [0.3.7](https://github.com/currents-dev/currents-playwright/compare/0.3.6...0.3.7) (2023-04-11)

### Bug Fixes

- send raw results for troubleshooting ([712cf7e](https://github.com/currents-dev/currents-playwright/commit/712cf7e0865ea3fc7488aa8fb01c0fde8db8fde6))

## [0.3.6](https://github.com/currents-dev/currents-playwright/compare/0.3.5...0.3.6) (2023-04-10)

### Bug Fixes

- handle expected vs actual tests status ([6d3c5cb](https://github.com/currents-dev/currents-playwright/commit/6d3c5cb18d1cad94f856eb37fa10cacf0d13ac89))

## [0.3.5](https://github.com/currents-dev/currents-playwright/compare/0.3.4...0.3.5) (2023-03-31)

### Bug Fixes

- use execa to support windows ([b20b746](https://github.com/currents-dev/currents-playwright/commit/b20b746c08f04f8d714d4d39eae49c86387ffc8f))

## [0.3.4](https://github.com/currents-dev/currents-playwright/compare/0.3.3...0.3.4) (2023-02-20)

### Bug Fixes

- wait for flaky test to complete ([95fffef](https://github.com/currents-dev/currents-playwright/commit/95fffef93522391ad665e14841a976fe61da747e))

## [0.3.3](https://github.com/currents-dev/currents-playwright/compare/0.3.2...0.3.3) (2023-02-08)

## [0.3.2](https://github.com/currents-dev/currents-playwright/compare/0.3.1...0.3.2) (2023-02-08)

### Bug Fixes

- handle empty results ([ac09874](https://github.com/currents-dev/currents-playwright/commit/ac098748be6cf135c829b9e3694e19f87ea120ae))

## [0.3.1](https://github.com/currents-dev/currents-playwright/compare/0.3.0...0.3.1) (2023-02-06)

### Bug Fixes

- remove requiring pw+pwc version ([9481736](https://github.com/currents-dev/currents-playwright/commit/9481736139dc96a781bd8103d9fac8651c422b92))

# [0.3.0](https://github.com/currents-dev/currents-playwright/compare/0.2.2...0.3.0) (2023-02-06)

### Bug Fixes

- exist with pw's exit status ([983bb0c](https://github.com/currents-dev/currents-playwright/commit/983bb0c3aece981c6c28fd2f36b2fdef63320d20))
- handle expired run case ([5d008cf](https://github.com/currents-dev/currents-playwright/commit/5d008cfc881c70d5c6471c5032654cabcee14606))
- use claimedCount > 1 ([ee40f1e](https://github.com/currents-dev/currents-playwright/commit/ee40f1e01ff9f17468a1cb975a45456ca3fe8ba0))
- use dedicated pw stdout endpoint ([62f4a48](https://github.com/currents-dev/currents-playwright/commit/62f4a481cbef8e93d1a500942d5df84cca9379dd))
- use PR ref for clear message ([3c7e6a6](https://github.com/currents-dev/currents-playwright/commit/3c7e6a671d4eb8dd6883f0c86e93db3b6c6c6e5e))

### Features

- upload results and stdout in parallel ([4e7e165](https://github.com/currents-dev/currents-playwright/commit/4e7e1657e6a3be03ab697e24b28f2d8e3966dbfe))
- upload results in 1 requests ([93053d1](https://github.com/currents-dev/currents-playwright/commit/93053d19ca6d3391a7df11c29b7edc8e0745d751))

## [0.2.2](https://github.com/currents-dev/currents-playwright/compare/0.2.0...0.2.2) (2023-01-31)

### Bug Fixes

- skip uploading results for errors ([dd0d3a8](https://github.com/currents-dev/currents-playwright/commit/dd0d3a8122f66b305cb94341b35515eac84e5033))

# [0.2.0](https://github.com/currents-dev/currents-playwright/compare/0.1.1...0.2.0) (2023-01-31)

### Bug Fixes

- fix counting repeated tests and their status ([f24694a](https://github.com/currents-dev/currents-playwright/commit/f24694a4d961dd655af4938bcbed45c97ae8a5dd))

### Features

- add http errors handlers ([044a93f](https://github.com/currents-dev/currents-playwright/commit/044a93f93c3c351c69abe220c1596ecf762840a0))
- create instances in advance ([830064b](https://github.com/currents-dev/currents-playwright/commit/830064bb7d501162d26da2bc03b61f36d5d30de2))
- upload results in parallel ([b6f3179](https://github.com/currents-dev/currents-playwright/commit/b6f3179db2dfe4a3d8ce61cbceffae892275dfc2))

## [0.1.1](https://github.com/currents-dev/currents-playwright/compare/0.1.0...0.1.1) (2023-01-26)

# [0.1.0](https://github.com/currents-dev/currents-playwright/compare/f50c00cd0eff6c10728daae8577a1e80d35c5c34...0.1.0) (2023-01-26)

### Bug Fixes

- "skipped" > "pending". Closes [#28](https://github.com/currents-dev/currents-playwright/issues/28) ([96611fe](https://github.com/currents-dev/currents-playwright/commit/96611feab062329e6394acb3ac5fb17c3d0576f2))
- various fixes from local testing ([ace1782](https://github.com/currents-dev/currents-playwright/commit/ace1782a0030203ccbd818b68dc9a3e7fbf06299))

### Features

- add basic Playwright reporter ([f50c00c](https://github.com/currents-dev/currents-playwright/commit/f50c00cd0eff6c10728daae8577a1e80d35c5c34))
- create run on onBegin ([a30c33c](https://github.com/currents-dev/currents-playwright/commit/a30c33c62425920c424551a85d7f966866178dc7))
- get git info in test reporter ([845c83d](https://github.com/currents-dev/currents-playwright/commit/845c83dcb4fb4a5d9a8f740026d1fdddede9f06b))
- make initial setup call from Playwright ([ac5083b](https://github.com/currents-dev/currents-playwright/commit/ac5083bb3c1d585293d090fc6475eb173373ecab))
- sent version headers with network requests ([3ad1896](https://github.com/currents-dev/currents-playwright/commit/3ad1896c239c944ed657a471eeb6e07ea80b762e))

# [0.4.0](https://github.com/currents-dev/currents-playwright/compare/0.3.8-beta.0...0.4.0) (2023-05-05)

### Bug Fixes

- allow debugging extensions ([17b5a5f](https://github.com/currents-dev/currents-playwright/commit/17b5a5f0047df8b4fa610b07d47a88a71be34a7d))
- send ciBuildId when creating a run ([d47a2c1](https://github.com/currents-dev/currents-playwright/commit/d47a2c176b308e842eaf67439679354cee82a073))
- show upload warnings at the end of execution ([63c91f3](https://github.com/currents-dev/currents-playwright/commit/63c91f33cc253ef432236e1664a644df40d4a5c1))
- upload stdout and artifacts in parallel ([10a0d2d](https://github.com/currents-dev/currents-playwright/commit/10a0d2d891a1a0c71dccfb7842a37089e26b5647))
- use debug extensions ([0512596](https://github.com/currents-dev/currents-playwright/commit/05125960e25fb532824d268c1a46e82682faa163))

### Features

- refactor + stabilize network uploads ([1f945b6](https://github.com/currents-dev/currents-playwright/commit/1f945b6168e601e0f1f48cf1e4bfd64fd0ee3e25))
- refactor + stabilize network uploads ([1b1cbe9](https://github.com/currents-dev/currents-playwright/commit/1b1cbe9cf136efb056299b257e88fba31fdb2a68))

## [0.3.8-beta.0](https://github.com/currents-dev/currents-playwright/compare/0.3.7...0.3.8-beta.0) (2023-04-20)

### Bug Fixes

- use network retries, enhance debugging ([f996250](https://github.com/currents-dev/currents-playwright/commit/f996250a3b52ade75e0a676c31d50153c2c12b8b))

## [0.3.7](https://github.com/currents-dev/currents-playwright/compare/0.3.6...0.3.7) (2023-04-11)

### Bug Fixes

- send raw results for troubleshooting ([712cf7e](https://github.com/currents-dev/currents-playwright/commit/712cf7e0865ea3fc7488aa8fb01c0fde8db8fde6))

## [0.3.6](https://github.com/currents-dev/currents-playwright/compare/0.3.5...0.3.6) (2023-04-10)

### Bug Fixes

- handle expected vs actual tests status ([6d3c5cb](https://github.com/currents-dev/currents-playwright/commit/6d3c5cb18d1cad94f856eb37fa10cacf0d13ac89))

## [0.3.5](https://github.com/currents-dev/currents-playwright/compare/0.3.4...0.3.5) (2023-03-31)

### Bug Fixes

- use execa to support windows ([b20b746](https://github.com/currents-dev/currents-playwright/commit/b20b746c08f04f8d714d4d39eae49c86387ffc8f))

## [0.3.4](https://github.com/currents-dev/currents-playwright/compare/0.3.3...0.3.4) (2023-02-20)

### Bug Fixes

- wait for flaky test to complete ([95fffef](https://github.com/currents-dev/currents-playwright/commit/95fffef93522391ad665e14841a976fe61da747e))
- use relative files location https://github.com/currents-dev/currents-playwright/pull/72
- add CI git and build info https://github.com/currents-dev/currents-playwright/pull/71

## [0.3.3](https://github.com/currents-dev/currents-playwright/compare/0.3.2...0.3.3) (2023-02-08)

## [0.3.2](https://github.com/currents-dev/currents-playwright/compare/0.3.1...0.3.2) (2023-02-08)

### Bug Fixes

- handle empty results ([ac09874](https://github.com/currents-dev/currents-playwright/commit/ac098748be6cf135c829b9e3694e19f87ea120ae))

## [0.3.1](https://github.com/currents-dev/currents-playwright/compare/0.3.0...0.3.1) (2023-02-06)

### Bug Fixes

- remove requiring pw+pwc version ([9481736](https://github.com/currents-dev/currents-playwright/commit/9481736139dc96a781bd8103d9fac8651c422b92))

## [0.3.0](https://github.com/currents-dev/currents-playwright/compare/0.2.2...0.3.0) (2023-02-06)

### Bug Fixes

- exit with pw's exit status ([983bb0c](https://github.com/currents-dev/currents-playwright/commit/983bb0c3aece981c6c28fd2f36b2fdef63320d20))
- handle expired run case ([5d008cf](https://github.com/currents-dev/currents-playwright/commit/5d008cfc881c70d5c6471c5032654cabcee14606))
- use claimedCount > 1 ([ee40f1e](https://github.com/currents-dev/currents-playwright/commit/ee40f1e01ff9f17468a1cb975a45456ca3fe8ba0))
- use dedicated pw stdout endpoint ([62f4a48](https://github.com/currents-dev/currents-playwright/commit/62f4a481cbef8e93d1a500942d5df84cca9379dd))
- use PR ref for clear message ([3c7e6a6](https://github.com/currents-dev/currents-playwright/commit/3c7e6a671d4eb8dd6883f0c86e93db3b6c6c6e5e))

### Features

- upload results and stdout in parallel ([4e7e165](https://github.com/currents-dev/currents-playwright/commit/4e7e1657e6a3be03ab697e24b28f2d8e3966dbfe))
- upload results in 1 requests ([93053d1](https://github.com/currents-dev/currents-playwright/commit/93053d19ca6d3391a7df11c29b7edc8e0745d751))

## [0.2.2](https://github.com/currents-dev/currents-playwright/compare/0.2.0...0.2.2) (2023-01-31)

### Bug Fixes

- skip uploading results for errors ([dd0d3a8](https://github.com/currents-dev/currents-playwright/commit/dd0d3a8122f66b305cb94341b35515eac84e5033))

## [0.2.1](https://github.com/currents-dev/currents-playwright/compare/0.2.0...0.2.1) (2023-01-31)

## [0.2.0](https://github.com/currents-dev/currents-playwright/compare/0.1.1...0.2.0) (2023-01-31)

### Bug Fixes

- fix counting repeated tests and their status ([f24694a](https://github.com/currents-dev/currents-playwright/commit/f24694a4d961dd655af4938bcbed45c97ae8a5dd))

### Features

- add http errors handlers ([044a93f](https://github.com/currents-dev/currents-playwright/commit/044a93f93c3c351c69abe220c1596ecf762840a0))
- create instances in advance ([830064b](https://github.com/currents-dev/currents-playwright/commit/830064bb7d501162d26da2bc03b61f36d5d30de2))
- upload results in parallel ([b6f3179](https://github.com/currents-dev/currents-playwright/commit/b6f3179db2dfe4a3d8ce61cbceffae892275dfc2))

## [0.1.1](https://github.com/currents-dev/currents-playwright/compare/0.1.0...0.1.1) (2023-01-26)

## 0.1.0 (2023-01-26)

### Bug Fixes

- "skipped" > "pending". Closes [#28](https://github.com/currents-dev/currents-playwright/issues/28) ([96611fe](https://github.com/currents-dev/currents-playwright/commit/96611feab062329e6394acb3ac5fb17c3d0576f2))
- various fixes from local testing ([ace1782](https://github.com/currents-dev/currents-playwright/commit/ace1782a0030203ccbd818b68dc9a3e7fbf06299))

### Features

- add basic Playwright reporter ([f50c00c](https://github.com/currents-dev/currents-playwright/commit/f50c00cd0eff6c10728daae8577a1e80d35c5c34))
- create run on onBegin ([a30c33c](https://github.com/currents-dev/currents-playwright/commit/a30c33c62425920c424551a85d7f966866178dc7))
- get git info in test reporter ([845c83d](https://github.com/currents-dev/currents-playwright/commit/845c83dcb4fb4a5d9a8f740026d1fdddede9f06b))
- make initial setup call from Playwright ([ac5083b](https://github.com/currents-dev/currents-playwright/commit/ac5083bb3c1d585293d090fc6475eb173373ecab))
- sent version headers with network requests ([3ad1896](https://github.com/currents-dev/currents-playwright/commit/3ad1896c239c944ed657a471eeb6e07ea80b762e))
